

export interface Position {
  x: number;
  y: number;
}

export enum BallType {
  MONEY = "money",
  MIRROR_OBSTACLE = "mirror_obstacle",
}

export interface Ball {
  id: number;
  type: BallType;
  position: Position;
  color: string;
  percentage: number; 
  value: number; 
  isEaten: boolean;
  hasLanded?: boolean; 
  targetY?: number;    
}

export enum GameMode {
  REAL = "Real Game",
  MOCK = "Mock Game",
}

export enum Direction {
  UP,
  DOWN,
  LEFT,
  RIGHT,
}

export enum GameStatus {
  READY,
  PLAYING,
  GAME_OVER, // Generic game over
  WON,       // All money balls eaten within time
  INSUFFICIENT_FUNDS,
  TIME_UP,   // Game over specifically due to time
}

export interface GameSettings {
  currency: string;
  stakeAmount: number;
  gameMode: GameMode;
}

export interface WalletBalances {
  deposit: number;
  mock: number;
  admin: number;
}

// Game Event System
export type GameEventPayloadMap = {
  MONEY_EATEN: { value: number; percentage: number; position: Position };
  OBSTACLE_HIT: { scorePenalty: number; lengthReduction: number; position: Position };
  GAME_WON: { finalScore: number; timeLeft: number; totalObstaclePenalty: number; refundApplied: number };
  GAME_OVER: { reason: 'collision' | 'too_short' | 'time_up'; finalScore: number; stakeCommitted: number, totalObstaclePenalty: number; refundApplied: number; };
  NEW_GAME_PROMPT: { visible: boolean; countdown: number };
};

export type GameEventType = keyof GameEventPayloadMap;

export interface GameEvent<T extends GameEventType = GameEventType> {
  id: string; // Unique ID, e.g., Date.now().toString()
  type: T;
  payload: GameEventPayloadMap[T];
}

// New interface for storing game history
export interface GameRecord {
  id: string;
  userName: string; 
  playerPhoneNumber: string; 
  gameEndTime: Date;
  stakeAmount: number;
  currency: string;
  gameMode: GameMode;
  finalScore: number; // Player's score at the end (gross score before refund)
  status: GameStatus; // WON, GAME_OVER, TIME_UP
  reason?: GameEventPayloadMap['GAME_OVER']['reason']; // If GAME_OVER
  timeLeft?: number; // If WON
  amountLostToAdmin: number;
  amountLostToObstacles: number;
  refundApplied: number; // Amount of stake refunded to the player
}

// Authentication types
export type UserRole = 'user' | 'admin';

export interface User {
  id: string;
  name: string;
  username: string;
  phoneNumber: string;
  email: string;
  passwordHash: string; // For simulation, will store plain text password
  dateOfBirth: string; // YYYY-MM-DD
  country: string;
  stateOrRegion: string;
  locality: string;
  role: UserRole;
  createdAt: string; // ISO string date
}

export type AuthView = 'login' | 'signup';