
import React, { useState, useEffect, useCallback } from 'react';
import AuthPage from './components/auth/AuthPage';
import AdminDashboard from './components/admin/AdminDashboard';
import GameClient from './GameClient';
import { User, WalletBalances } from './types';
import { ADMIN_USERNAME, ADMIN_PASSWORD, INITIAL_DEPOSIT_WALLET_BALANCE, INITIAL_MOCK_WALLET_BALANCE, INITIAL_ADMIN_WALLET_BALANCE } from './constants';

const getStoredUsers = (): User[] => {
  const usersJson = localStorage.getItem('efadoUsers');
  if (usersJson) {
    try {
      return JSON.parse(usersJson);
    } catch (e) {
      console.error("Error parsing users from localStorage", e);
      return [];
    }
  }
  return [];
};

const getStoredCurrentUser = (): User | null => {
  const userJson = localStorage.getItem('efadoCurrentUser');
  if (userJson) {
    try {
      return JSON.parse(userJson);
    } catch (e) {
      console.error("Error parsing current user from localStorage", e);
      return null;
    }
  }
  return null;
};

// Helper to get global wallet balances from localStorage
const getStoredGlobalWallets = (): WalletBalances => {
  const walletsJson = localStorage.getItem('efadoGlobalWallets');
  if (walletsJson) {
    try {
      return JSON.parse(walletsJson);
    } catch (e) {
      console.error("Error parsing global wallets from localStorage", e);
    }
  }
  return {
    deposit: INITIAL_DEPOSIT_WALLET_BALANCE,
    mock: INITIAL_MOCK_WALLET_BALANCE,
    admin: INITIAL_ADMIN_WALLET_BALANCE,
  };
};


const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => getStoredCurrentUser());
  const [storedUsers, setStoredUsers] = useState<User[]>(() => {
    const users = getStoredUsers();
    const adminExists = users.some(u => u.username === ADMIN_USERNAME);
    if (!adminExists) {
      const adminUser: User = {
        id: 'admin_user_001',
        name: 'Administrator',
        username: ADMIN_USERNAME,
        phoneNumber: '0000000000',
        email: 'admin@efado.com',
        passwordHash: ADMIN_PASSWORD,
        dateOfBirth: '1970-01-01',
        country: 'N/A',
        stateOrRegion: 'N/A',
        locality: 'N/A',
        role: 'admin',
        createdAt: new Date().toISOString(),
      };
      const updatedUsers = [...users, adminUser];
      localStorage.setItem('efadoUsers', JSON.stringify(updatedUsers));
      return updatedUsers;
    }
    return users;
  });

  const [globalWalletBalances, setGlobalWalletBalances] = useState<WalletBalances>(() => getStoredGlobalWallets());

  useEffect(() => {
    localStorage.setItem('efadoUsers', JSON.stringify(storedUsers));
  }, [storedUsers]);

  useEffect(() => {
    localStorage.setItem('efadoGlobalWallets', JSON.stringify(globalWalletBalances));
  }, [globalWalletBalances]);

  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('efadoCurrentUser', JSON.stringify(user));
    // Reset or load user-specific wallet balances if needed here
    // For now, global wallets persist across users for simplicity in this version
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('efadoCurrentUser');
  };

  // Wallet update functions to be passed down
  const updateGlobalDepositWallet = useCallback((amount: number) => {
    setGlobalWalletBalances(prev => ({ ...prev, deposit: prev.deposit + amount }));
  }, []);

  const updateGlobalMockWallet = useCallback((amount: number) => {
    setGlobalWalletBalances(prev => ({ ...prev, mock: prev.mock + amount }));
  }, []);
  
  const updateGlobalAdminWallet = useCallback((amount: number) => {
    setGlobalWalletBalances(prev => ({ ...prev, admin: prev.admin + amount }));
  }, []);

  const handlePlayerCashOut = useCallback((amount: number) => {
    if (globalWalletBalances.deposit >= amount) {
      setGlobalWalletBalances(prev => ({ ...prev, deposit: prev.deposit - amount }));
      // Here you would integrate with a real payment gateway
      console.log(`Cashed out ${amount} from deposit wallet.`);
      return true;
    }
    console.warn("Cash out failed: Insufficient funds in deposit wallet.");
    return false;
  }, [globalWalletBalances.deposit]);

  const handleAdminWithdraw = useCallback((amount: number) => {
    if (globalWalletBalances.admin >= amount) {
      setGlobalWalletBalances(prev => ({ ...prev, admin: prev.admin - amount }));
      // Real payment gateway integration for admin
      console.log(`Admin withdrew ${amount} from admin profit wallet.`);
      return true;
    }
    console.warn("Admin withdrawal failed: Insufficient funds in admin profit wallet.");
    return false;
  }, [globalWalletBalances.admin]);


  if (!currentUser) {
    return (
      <AuthPage 
        onAuthSuccess={handleAuthSuccess} 
        storedUsers={storedUsers}
        setStoredUsers={setStoredUsers}
      />
    );
  }

  if (currentUser.role === 'admin') {
    return (
      <AdminDashboard 
        user={currentUser} 
        onLogout={handleLogout}
        adminProfitWalletBalance={globalWalletBalances.admin}
        onAdminWithdraw={handleAdminWithdraw}
        // Pass global wallet updaters if admin mock game needs to affect them (typically it wouldn't for admin profit)
        // For the mock game within admin, GameClient will need initial balances.
        // The admin's "mock game" uses its own internal admin wallet logic if not tied to global.
        // However, if the mock game is meant to operate on the global mock wallet, pass that updater.
        initialMockBalanceForGameClient={globalWalletBalances.mock}
        updateGlobalMockWalletForGameClient={updateGlobalMockWallet}
      />
    );
  }

  return (
    <GameClient 
      currentUser={currentUser} 
      onLogout={handleLogout} 
      initialWalletBalances={globalWalletBalances}
      updateGlobalDepositWallet={updateGlobalDepositWallet}
      updateGlobalMockWallet={updateGlobalMockWallet}
      updateGlobalAdminWallet={updateGlobalAdminWallet}
      onPlayerCashOut={handlePlayerCashOut}
    />
  );
};

export default App;
