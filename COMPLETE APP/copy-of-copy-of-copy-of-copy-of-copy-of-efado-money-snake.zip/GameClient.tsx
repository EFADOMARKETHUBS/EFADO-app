
import React, { useState, useCallback, useEffect, useRef } from 'react';
import GameStage from './components/GameStage';
import ControlsPanel from './components/ControlsPanel';
import Modal from './components/Modal';
import WalletPanel from './components/WalletPanel';
import DepositModal from './components/DepositModal';
import Button from './components/Button';
import GameActionsPanel from './components/GameActionsPanel'; 
import AskGeminiPanel from './components/AskGeminiPanel';
import DashboardModal from './components/DashboardModal';
import CollapsibleGameInfo from './components/CollapsibleGameInfo';
import CashOutModal from './components/CashOutModal'; // New
import useGameLogic from './hooks/useGameLogic';
import { GameMode, GameStatus, GameSettings, WalletBalances, GameEvent, GameEventPayloadMap, Position, GameRecord, GameEventType, User } from './types';
import { 
  CURRENCIES, 
  STAKE_AMOUNTS, 
  AUTO_RESTART_DELAY_SECONDS, 
  GAME_EVENT_EFFECT_DURATION, 
  GRID_SIZE,
} from './constants';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const playSound = (soundName: string) => {
  console.log(`PLAYING SOUND: ${soundName}`);
};

interface EffectText {
  id: string;
  text: string;
  className: string; 
  style: React.CSSProperties; 
}

interface GameClientProps {
  currentUser: User;
  onLogout: () => void;
  isAdminView?: boolean;
  forcedGameMode?: GameMode;
  
  initialWalletBalances: WalletBalances;
  updateGlobalDepositWallet: (amount: number) => void;
  updateGlobalMockWallet: (amount: number) => void;
  updateGlobalAdminWallet: (amount: number) => void;
  onPlayerCashOut: (amount: number, details: any) => boolean; // Details for simulation
}

const GameClient: React.FC<GameClientProps> = ({ 
  currentUser, 
  onLogout, 
  isAdminView = false, 
  forcedGameMode,
  initialWalletBalances,
  updateGlobalDepositWallet,
  updateGlobalMockWallet,
  updateGlobalAdminWallet,
  onPlayerCashOut
}) => {
  const [settings, setSettings] = useState<GameSettings>({
    currency: CURRENCIES[0],
    stakeAmount: STAKE_AMOUNTS[0],
    gameMode: forcedGameMode || GameMode.MOCK,
  });

  // Wallet balances are now primarily from props
  const currentWalletBalances = initialWalletBalances;

  const [isGamePausedForEffect, setIsGamePausedForEffect] = useState(false); 

  const { snake, balls, score, gameStatus, lastGameEvent, startGame, resetGame, timeLeft } = useGameLogic({
    settings,
    // Pass wallet updater functions to useGameLogic
    updateDepositWallet: updateGlobalDepositWallet,
    updateMockWallet: updateGlobalMockWallet,
    updateAdminWallet: updateGlobalAdminWallet,
    getWalletBalances: () => currentWalletBalances, // Provide a way for useGameLogic to read current balances
    isGamePausedForEffect, 
  });

  const [isShaking, setIsShaking] = useState(false);
  const [gameAreaZoomClass, setGameAreaZoomClass] = useState('');
  const [activeOverlay, setActiveOverlay] = useState<string | null>(null);
  const [effectTexts, setEffectTexts] = useState<EffectText[]>([]);
  
  const [isGameEndModalOpen, setIsGameEndModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState("");
  const [modalTitleClassName, setModalTitleClassName] = useState<string | undefined>(undefined);
  const [modalContent, setModalContent] = useState<React.ReactNode>(null);
  const [autoRestartCountdown, setAutoRestartCountdown] = useState(AUTO_RESTART_DELAY_SECONDS);
  const autoRestartTimerRef = useRef<number | null>(null);
  const postGameCooldownTimerRef = useRef<number | null>(null);
  
  const [isPostGameCooldownActive, setIsPostGameCooldownActive] = useState(false);
  const [gameHistory, setGameHistory] = useState<GameRecord[]>([]);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);

  const gameAreaRef = useRef<HTMLDivElement>(null);

  const [geminiUserInput, setGeminiUserInput] = useState('');
  const [geminiResponse, setGeminiResponse] = useState('');
  const [isGeminiLoading, setIsGeminiLoading] = useState(false);
  const [geminiError, setGeminiError] = useState('');
  
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isCashOutModalOpen, setIsCashOutModalOpen] = useState(false); // New state


  useEffect(() => {
    if (forcedGameMode && settings.gameMode !== forcedGameMode) {
      setSettings(prev => ({ ...prev, gameMode: forcedGameMode }));
    }
  }, [forcedGameMode, settings.gameMode]);


  const handleSettingsChange = useCallback(<K extends keyof GameSettings>(key: K, value: GameSettings[K]) => {
    if (isAdminView && forcedGameMode && key === 'gameMode' && value !== forcedGameMode) {
        return;
    }
    setSettings(prev => ({ ...prev, [key]: value }));
  }, [isAdminView, forcedGameMode]);
  
  const clearEffects = (keepOverlayAndText?: boolean) => {
    setIsShaking(false);
    setGameAreaZoomClass('');
    if(!keepOverlayAndText) {
        setActiveOverlay(null);
    }
  };
  
  const addEffectText = (
    text: string,
    animationClassName: string,
    position: Position | undefined,
    textColor: string | undefined,
    duration = GAME_EVENT_EFFECT_DURATION,
    isCenteredOnScreen = false
  ) => {
    const id = Date.now().toString();
    let dynamicStyle: React.CSSProperties = { position: 'absolute' };

    if (textColor) {
      dynamicStyle.color = textColor;
    }

    if (position && gameAreaRef.current) {
      const stageElement = gameAreaRef.current.firstChild;
      if (stageElement && stageElement instanceof HTMLElement) {
        dynamicStyle.top = `${position.y * GRID_SIZE + GRID_SIZE / 2}px`;
        dynamicStyle.left = `${position.x * GRID_SIZE + GRID_SIZE / 2}px`;
      } else { 
        dynamicStyle.top = '50%';
        dynamicStyle.left = '50%';
        dynamicStyle.transform = 'translate(-50%, -50%)';
      }
    } else if (isCenteredOnScreen) {
      dynamicStyle.top = '50%';
      dynamicStyle.left = '50%';
      dynamicStyle.transform = 'translate(-50%, -50%)';
    }

    setEffectTexts(prev => [...prev, { id, text, className: animationClassName, style: dynamicStyle }]);
    setTimeout(() => {
      setEffectTexts(prev => prev.filter(et => et.id !== id));
    }, duration);
  };

  useEffect(() => {
    if (!lastGameEvent) return;
    clearEffects(true); 
    setIsGamePausedForEffect(false);
    const { type, payload } = lastGameEvent;
    let effectDuration = GAME_EVENT_EFFECT_DURATION;
    const valueAnimationDuration = 1500;

    if (type === 'MONEY_EATEN' || type === 'OBSTACLE_HIT') {
      setIsGamePausedForEffect(true);
      playSound(type === 'MONEY_EATEN' ? 'thunder' : 'shock_lightning');
      setIsShaking(true);
      if (type === 'MONEY_EATEN') {
        const eventPayload = payload as GameEventPayloadMap['MONEY_EATEN'];
        setGameAreaZoomClass('game-area-zoom-in');
        setActiveOverlay('money-ball-eat-overlay');
        addEffectText(`+${eventPayload.value.toFixed(2)}`, 'value-feedback-animation', eventPayload.position, 'gold', valueAnimationDuration);
      } else { 
        const eventPayload = payload as GameEventPayloadMap['OBSTACLE_HIT'];
        setGameAreaZoomClass('game-area-zoom-in-obstacle flashing-text-red-green');
        setActiveOverlay('obstacle-hit-overlay');
        if (eventPayload.scorePenalty > 0) {
          addEffectText(`-${eventPayload.scorePenalty.toFixed(2)}`, 'value-feedback-animation', eventPayload.position, 'white', valueAnimationDuration);
        }
        addEffectText(`-${eventPayload.lengthReduction > 0 ? `${eventPayload.lengthReduction} Segments, ` : ''}${eventPayload.scorePenalty > 0 ? `${eventPayload.scorePenalty.toFixed(2)} Score` : (eventPayload.lengthReduction > 0 ? "Segments Lost" : "Obstacle Grazed")}`, 'event-text-indicator obstacle-loss-indicator flashing-text-red-green bg-black/70', undefined, undefined, effectDuration + 500, false);
        effectDuration += 500;
      }
      setTimeout(() => {
        clearEffects();
        setIsGamePausedForEffect(false);
      }, effectDuration);
    } else if (type === 'GAME_WON') {
      const eventPayload = payload as GameEventPayloadMap['GAME_WON'];
      playSound('win_thunder_celebration');
      setActiveOverlay('winner-overlay'); 
      addEffectText("Winner! Winner! Winner!", "event-text-indicator winner-announcement", undefined, '#FFD700', 5000, true);
      setTimeout(() => addEffectText(`Total Score: ${eventPayload.finalScore.toFixed(2)} ${settings.currency}`, "event-text-indicator winner-score-animation text-2xl text-green-300 bg-black/60", undefined, undefined, 5000, true), 500);
      setTimeout(() => setActiveOverlay(null), 5500);
    } else if (type === 'GAME_OVER' || gameStatus === GameStatus.INSUFFICIENT_FUNDS) {
       clearEffects(); 
    }
  }, [lastGameEvent, settings.currency]);

  const recordGameHistory = (status: GameStatus, eventPayload?: GameEventPayloadMap[GameEventType]) => {
    let finalScore = 0;
    let amountLostToAdmin = 0;
    let amountLostToObstacles = 0;
    let stakeCommitted = settings.stakeAmount;
    let reason: GameEventPayloadMap['GAME_OVER']['reason'] | undefined = undefined;
    let timeLeftRecord: number | undefined = undefined;
    let actualRefundApplied = 0;

    if (status === GameStatus.WON && eventPayload && 'finalScore' in eventPayload) {
        const winPayload = eventPayload as GameEventPayloadMap['GAME_WON'];
        finalScore = winPayload.finalScore;
        timeLeftRecord = winPayload.timeLeft;
        amountLostToObstacles = winPayload.totalObstaclePenalty;
        actualRefundApplied = winPayload.refundApplied;
        if (settings.gameMode === GameMode.REAL && !isAdminView) {
            amountLostToAdmin = Math.max(0, stakeCommitted - (finalScore + actualRefundApplied));
        }
    } else if ((status === GameStatus.GAME_OVER || status === GameStatus.TIME_UP) && eventPayload && 'finalScore' in eventPayload && 'reason' in eventPayload) { 
        const gameOverPayload = eventPayload as GameEventPayloadMap['GAME_OVER'];
        finalScore = gameOverPayload.finalScore;
        stakeCommitted = gameOverPayload.stakeCommitted;
        amountLostToObstacles = gameOverPayload.totalObstaclePenalty;
        reason = gameOverPayload.reason;
        actualRefundApplied = gameOverPayload.refundApplied;
        if (settings.gameMode === GameMode.REAL && !isAdminView) {
             amountLostToAdmin = Math.max(0, stakeCommitted - (finalScore + actualRefundApplied));
        }
    } else if (status === GameStatus.INSUFFICIENT_FUNDS) {
        return; 
    }

    if (!isAdminView && (status === GameStatus.WON || status === GameStatus.GAME_OVER || status === GameStatus.TIME_UP)) {
        const newRecord: GameRecord = {
            id: Date.now().toString(),
            userName: currentUser.name, 
            playerPhoneNumber: currentUser.phoneNumber, 
            gameEndTime: new Date(),
            stakeAmount: stakeCommitted,
            currency: settings.currency,
            gameMode: settings.gameMode,
            finalScore: finalScore, 
            status: status,
            reason: reason,
            timeLeft: timeLeftRecord,
            amountLostToAdmin: amountLostToAdmin,
            amountLostToObstacles: amountLostToObstacles,
            refundApplied: actualRefundApplied,
        };
        setGameHistory(prev => [newRecord, ...prev]);
    }
  };

  const generateEndGameMessage = (status: GameStatus, eventPayload?: GameEventPayloadMap[GameEventType]) => {
    let baseMessage = "";
    let grossScoreFromEvent = 0; 
    let stakeForRound = settings.stakeAmount; 
    let obstacleLossForRound = 0;
    let actualRefundApplied = 0;
    let playerNetChangeText = "";
    let adminNetChangeText = "";

    if (eventPayload && 'stakeCommitted' in eventPayload) {
        stakeForRound = (eventPayload as GameEventPayloadMap['GAME_OVER']).stakeCommitted || settings.stakeAmount;
    }
    if (eventPayload && typeof (eventPayload as any).refundApplied === 'number') {
        actualRefundApplied = (eventPayload as GameEventPayloadMap['GAME_WON' | 'GAME_OVER']).refundApplied;
    }

    if (status === GameStatus.WON && eventPayload && 'finalScore' in eventPayload) {
        const winPayload = eventPayload as GameEventPayloadMap['GAME_WON'];
        baseMessage = `Congratulations! You ate all money balls with ${winPayload.timeLeft.toFixed(0)}s left!`;
        grossScoreFromEvent = winPayload.finalScore;
        obstacleLossForRound = winPayload.totalObstaclePenalty;
        const totalPlayerReceived = grossScoreFromEvent + actualRefundApplied;
        if (settings.gameMode === GameMode.REAL && !isAdminView) {
            playerNetChangeText = `Your total payout: ${totalPlayerReceived.toFixed(2)} ${settings.currency}. (Score: ${grossScoreFromEvent.toFixed(2)} + Refund: ${actualRefundApplied.toFixed(2)}). Your initial stake was ${stakeForRound.toFixed(2)} ${settings.currency}.`;
            const adminNetGainOrLoss = stakeForRound - totalPlayerReceived;
            adminNetChangeText = `Admin Wallet: Net ${adminNetGainOrLoss >= 0 ? 'gain' : 'loss'} of ${Math.abs(adminNetGainOrLoss).toFixed(2)} ${settings.currency} for this game.`;
        } else if (settings.gameMode === GameMode.MOCK || isAdminView) {
            playerNetChangeText = `Mock Wallet: Increased by ${grossScoreFromEvent.toFixed(2)} MOCK. (Stake of ${stakeForRound.toFixed(2)} MOCK was deducted at start).`;
             if (actualRefundApplied > 0 && (isAdminView || settings.gameMode === GameMode.MOCK)) {
                playerNetChangeText += ` A mock refund of ${actualRefundApplied.toFixed(2)} MOCK would have been applied.`;
            }
        }
    } else if ((status === GameStatus.GAME_OVER || status === GameStatus.TIME_UP) && eventPayload && 'finalScore' in eventPayload && 'reason' in eventPayload) { 
        const gameOverPayload = eventPayload as GameEventPayloadMap['GAME_OVER'];
        grossScoreFromEvent = gameOverPayload.finalScore; 
        obstacleLossForRound = gameOverPayload.totalObstaclePenalty;
        if (status === GameStatus.TIME_UP) baseMessage = "Game Over: Time's up!";
        else {
            switch (gameOverPayload.reason) {
                case 'collision': baseMessage = "Game Over: Collision!"; break;
                case 'too_short': baseMessage = "Game Over: Snake is too short!"; break;
                default: baseMessage = "Game Over!"; 
            }
        }
        const totalPlayerReceived = grossScoreFromEvent + actualRefundApplied;
        if (settings.gameMode === GameMode.REAL && !isAdminView) {
            playerNetChangeText = `From your stake of ${stakeForRound.toFixed(2)} ${settings.currency}, you recovered ${grossScoreFromEvent.toFixed(2)} through score and received a refund of ${actualRefundApplied.toFixed(2)} ${settings.currency}. Total returned: ${totalPlayerReceived.toFixed(2)} ${settings.currency}.`;
            const adminNetGainOrLoss = stakeForRound - totalPlayerReceived;
            adminNetChangeText = `Admin Wallet: Net ${adminNetGainOrLoss >= 0 ? 'gain' : 'loss'} of ${Math.abs(adminNetGainOrLoss).toFixed(2)} ${settings.currency} for this game.`;
        } else if (settings.gameMode === GameMode.MOCK || isAdminView) {
             playerNetChangeText = `Mock Wallet: ${grossScoreFromEvent.toFixed(2)} MOCK was returned. (Stake of ${stakeForRound.toFixed(2)} MOCK was deducted at start).`;
             if (actualRefundApplied > 0 && (isAdminView || settings.gameMode === GameMode.MOCK)) {
                playerNetChangeText += ` A mock refund of ${actualRefundApplied.toFixed(2)} MOCK would have been applied.`;
            }
        }
    } else if (status === GameStatus.INSUFFICIENT_FUNDS) {
        baseMessage = `Not enough funds to start. Required: ${stakeForRound.toFixed(2)} ${settings.gameMode === GameMode.REAL ? settings.currency: 'MOCK'}.`;
        grossScoreFromEvent = 0; 
    }

    const obstacleLossDisplay = obstacleLossForRound > 0 ? `Value lost to Mirror Obstacles during game: ${obstacleLossForRound.toFixed(2)} ${settings.currency}.` : "";
    const refundDisplay = actualRefundApplied > 0 && (settings.gameMode === GameMode.REAL && !isAdminView) ? `A refund of ${actualRefundApplied.toFixed(2)} ${settings.currency} was applied to your payout.` : "";

    return (
        <div className="space-y-2 text-sm">
            <p className="font-bold text-base">{baseMessage}</p>
            <p>Your Score for this Round: {grossScoreFromEvent.toFixed(2)} {settings.gameMode === GameMode.MOCK || isAdminView ? 'MOCK' : settings.currency}</p>
            {refundDisplay && <p className="text-blue-300">{refundDisplay}</p>}
            {playerNetChangeText && <p>{playerNetChangeText}</p>}
            {obstacleLossDisplay && <p className="text-slate-400">{obstacleLossDisplay}</p>}
            {adminNetChangeText && (settings.gameMode === GameMode.REAL && !isAdminView) && <p className="text-slate-400">{adminNetChangeText}</p>}
        </div>
    );
  };
  
  const handleCloseGameEndModal = () => {
    if (autoRestartTimerRef.current) {
      clearInterval(autoRestartTimerRef.current);
      autoRestartTimerRef.current = null;
    }
    setIsGameEndModalOpen(false);
    if (!isAdminView && gameStatus !== GameStatus.INSUFFICIENT_FUNDS && !isPostGameCooldownActive) {
      resetGame();
    } else if (isAdminView && gameStatus !== GameStatus.INSUFFICIENT_FUNDS) {
        if (!isPostGameCooldownActive) resetGame();
    }
  };

  useEffect(() => {
    if (autoRestartTimerRef.current) clearInterval(autoRestartTimerRef.current);
    if (postGameCooldownTimerRef.current) clearTimeout(postGameCooldownTimerRef.current);
    setAutoRestartCountdown(AUTO_RESTART_DELAY_SECONDS); 

    if (gameStatus === GameStatus.GAME_OVER || gameStatus === GameStatus.WON || gameStatus === GameStatus.TIME_UP || gameStatus === GameStatus.INSUFFICIENT_FUNDS) {
      setIsGameEndModalOpen(true);
      let currentModalTitleText = "Game Result";
      let currentModalTitleClass: string | undefined = undefined;
      let relevantPayloadForModal: GameEventPayloadMap[GameEventType] | undefined = undefined;
      
      if (lastGameEvent) {
          if ( (gameStatus === GameStatus.WON && lastGameEvent.type === 'GAME_WON') ||
               ((gameStatus === GameStatus.GAME_OVER || gameStatus === GameStatus.TIME_UP) && lastGameEvent.type === 'GAME_OVER') ||
               (gameStatus === GameStatus.INSUFFICIENT_FUNDS && lastGameEvent.type === 'GAME_OVER')
             ) {
            relevantPayloadForModal = lastGameEvent.payload as GameEventPayloadMap[GameEventType];
          }
      }
      
      if (gameStatus === GameStatus.INSUFFICIENT_FUNDS) {
        currentModalTitleText = "Funding Issue";
      } else if (gameStatus === GameStatus.WON) {
        currentModalTitleText = "Victory!";
        currentModalTitleClass = "text-yellow-400 neon-text-gold";
      } else if (gameStatus === GameStatus.TIME_UP) {
        currentModalTitleText = "Time's Up!";
        currentModalTitleClass = "text-red-500 neon-text-red";
      } else if (gameStatus === GameStatus.GAME_OVER) { 
        currentModalTitleText = "Game Over!"; 
        currentModalTitleClass = "text-red-500 neon-text-red";
      }
      
      setModalTitle(currentModalTitleText);
      setModalTitleClassName(currentModalTitleClass);
      
      if (!isAdminView) {
        recordGameHistory(gameStatus, relevantPayloadForModal);
      }
      setModalContent(generateEndGameMessage(gameStatus, relevantPayloadForModal));

      if (gameStatus !== GameStatus.INSUFFICIENT_FUNDS) { 
        setIsPostGameCooldownActive(true);
        postGameCooldownTimerRef.current = window.setTimeout(() => setIsPostGameCooldownActive(false), AUTO_RESTART_DELAY_SECONDS * 1000);
        if (!isAdminView || (isAdminView )) {
            autoRestartTimerRef.current = window.setInterval(() => {
                setAutoRestartCountdown(prev => {
                    if (prev <= 1) {
                        if(autoRestartTimerRef.current) clearInterval(autoRestartTimerRef.current);
                        setIsGameEndModalOpen(false); 
                        resetGame(); 
                        return 0;
                    }
                    return prev - 1;
                });
            }, 1000);
        }
      }
    } else {
        setIsGameEndModalOpen(false); 
        setIsPostGameCooldownActive(false); 
        setModalTitleClassName(undefined); 
    }
     return () => {
        if (autoRestartTimerRef.current) clearInterval(autoRestartTimerRef.current);
        if (postGameCooldownTimerRef.current) clearTimeout(postGameCooldownTimerRef.current);
    };
  }, [gameStatus, lastGameEvent, isAdminView]); 

  const handleStartGame = () => {
    if (isPostGameCooldownActive && !isAdminView) return; 
    if (isGameEndModalOpen) handleCloseGameEndModal(); 
    if (gameStatus !== GameStatus.READY && gameStatus !== GameStatus.INSUFFICIENT_FUNDS) {
        resetGame(); 
    }
    clearEffects();
    setIsGamePausedForEffect(false); 
    setIsPostGameCooldownActive(false);
    if (postGameCooldownTimerRef.current) { clearTimeout(postGameCooldownTimerRef.current); postGameCooldownTimerRef.current = null; }
    if (autoRestartTimerRef.current) { clearInterval(autoRestartTimerRef.current); autoRestartTimerRef.current = null; }
    setAutoRestartCountdown(AUTO_RESTART_DELAY_SECONDS);
    setTimeout(() => startGame(), 50); 
  };
  
  const handleOpenDepositModal = () => setIsDepositModalOpen(true);
  const handleCloseDepositModal = () => setIsDepositModalOpen(false);
  const handleDeposit = (amount: number) => {
    updateGlobalDepositWallet(amount); // Use global updater
  };

  const handleOpenCashOutModal = () => setIsCashOutModalOpen(true);
  const handleCloseCashOutModal = () => setIsCashOutModalOpen(false);
  const handleConfirmCashOut = (amount: number, details: any) => {
    const success = onPlayerCashOut(amount, details); // Call App.tsx handler
    if (success) {
      // Optionally show feedback in CashOutModal or close it
      setIsCashOutModalOpen(false); 
    }
    // CashOutModal can handle its own internal success/error feedback based on the return
    return success;
  };
  
  const gameStatusText = GameStatus[gameStatus]?.replace(/_/g, ' ') || 'Unknown';
  const controlsAndStakeSelectorDisabled = gameStatus === GameStatus.PLAYING || isPostGameCooldownActive || (isAdminView && !!forcedGameMode);
  const effectiveStartButtonDisabled = isGamePausedForEffect || 
                                       (isPostGameCooldownActive && !isAdminView) || 
                                       (isGameEndModalOpen && autoRestartCountdown > 0 && gameStatus !== GameStatus.INSUFFICIENT_FUNDS && !isAdminView);

  const handleAskGemini = async () => {
    if (!geminiUserInput.trim()) { setGeminiError("Please enter a question."); return; }
    setIsGeminiLoading(true); setGeminiResponse(''); setGeminiError('');
    try {
      const apiKey = process.env.API_KEY || (window as any).frameElement?.getAttribute('data-api-key');
      if (!apiKey) { throw new Error("API_KEY is not configured."); }
      const ai = new GoogleGenAI({ apiKey });
      const response: GenerateContentResponse = await ai.models.generateContent({
          model: 'gemini-2.5-flash-preview-04-17', contents: geminiUserInput,
      });
      setGeminiResponse(response.text);
    } catch (error) {
      console.error("Error calling Gemini API:", error);
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      setGeminiError(`Error: ${errorMessage}. Check console for details. Ensure API_KEY is correctly set in the environment.`);
      setGeminiResponse('');
    } finally { setIsGeminiLoading(false); }
  };

  return (
    <div className={`min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center justify-center p-4 selection:bg-cyan-500 selection:text-cyan-900 overflow-hidden relative ${isAdminView ? 'admin-game-client-view' : ''}`}>
      {!isAdminView && (
        <header className="mb-6 text-center w-full max-w-5xl mx-auto">
          <div className="flex justify-between items-center">
              <div>
                <h1 className="text-4xl md:text-5xl efado-title-animated tracking-wider">EFADO Money Snake</h1>
                <p className="text-sm text-slate-300">Welcome, {currentUser.name}!</p>
              </div>
              <div>
                <Button onClick={() => setIsDashboardOpen(true)} variant="secondary" className="ml-2" animated={true}>View Dashboard</Button>
                <Button onClick={onLogout} variant="danger" className="ml-2">Logout</Button>
              </div>
          </div>
          <p className="text-slate-400 mt-2 text-sm md:text-base subtitle-animated-text">Eat balls, grow your snake, avoid obstacles, and manage your wallets to win!</p>
        </header>
      )}
      
      {!isAdminView && (
        <div className="marquee-container">
          <div className="marquee-scroll-text">
            Win Big! Double Your Stake! Be Smart to Get all the Balls! Eat Balls, Grow your Snake- Win More Money. Manage Your Wallets! &nbsp;&nbsp;&nbsp;&nbsp; Win Big! Double Your Stake! Be Smart to Get all the Balls! Eat Balls, Grow your Snake- Win More Money. Manage Your Wallets!
          </div>
        </div>
      )}

      <div className={`w-full ${isAdminView ? 'max-w-full' : 'max-w-5xl'} mx-auto`}>
        <ControlsPanel
          settings={settings}
          onSettingsChange={handleSettingsChange}
          disabled={controlsAndStakeSelectorDisabled || (isAdminView && !!forcedGameMode) }
        />

        <WalletPanel 
          balances={currentWalletBalances} // Use balances from props
          currency={settings.currency}
          onDepositClick={handleOpenDepositModal}
          onCashOutClick={!isAdminView ? handleOpenCashOutModal : undefined} // Add Cash Out
          className="my-4"
          depositButtonAnimated={true}
          disableDeposit={isAdminView} 
        />

        <div className="mt-1 flex flex-col items-center">
            <div ref={gameAreaRef} className={`flex-grow flex justify-center items-center mb-0 relative game-area-wrapper ${isShaking ? 'screen-shake' : ''} ${gameAreaZoomClass}`}>
                 <GameStage snake={snake} balls={balls} />
                 {activeOverlay && <div className={`effect-overlay ${activeOverlay}`}></div>}
                 {effectTexts.map(et => (
                    <div key={et.id} className={`${et.className} ${et.style.transform ? '' : 'transform -translate-x-1/2 -translate-y-1/2'}`} style={et.style}>
                        {et.text}
                    </div>
                 ))}
            </div>
            <GameActionsPanel stakeAmount={settings.stakeAmount} onStakeAmountChange={(value) => handleSettingsChange('stakeAmount', value)} onStartGame={handleStartGame} gameStatusText={gameStatusText} stakeSelectorDisabled={controlsAndStakeSelectorDisabled} startButtonDisabled={effectiveStartButtonDisabled} startButtonAnimated={true} />
        </div>
        
        <CollapsibleGameInfo gameStatus={gameStatus} isGamePausedForEffect={isGamePausedForEffect} isPostGameCooldownActive={isPostGameCooldownActive} autoRestartCountdown={autoRestartCountdown} timeLeft={timeLeft} score={score} settings={settings} className="mt-4" />

        {!isAdminView && ( 
            <AskGeminiPanel userInput={geminiUserInput} onUserInputChange={(e) => setGeminiUserInput(e.target.value)} onSubmit={handleAskGemini} response={geminiResponse} isLoading={isGeminiLoading} error={geminiError} className="mt-4" submitButtonAnimated={true} />
        )}
      </div>
      
      <Modal isOpen={isGameEndModalOpen} onClose={handleCloseGameEndModal} title={modalTitle} titleClassName={modalTitleClassName} showCloseButton={gameStatus === GameStatus.INSUFFICIENT_FUNDS || !isPostGameCooldownActive || isAdminView}
        customFooter={ <>
                {gameStatus !== GameStatus.INSUFFICIENT_FUNDS && (!isAdminView ) && (
                    <div className="mt-6 flex flex-col items-center space-y-2">
                        <p className="text-sm text-slate-400"> {autoRestartCountdown > 0 ? `Auto-starting new game in ${autoRestartCountdown}s...` : "Ready to Start."} </p>
                         {isPostGameCooldownActive && autoRestartCountdown > 0 && (<p className="text-xs text-orange-400">(Start button enabled in {autoRestartCountdown}s)</p> )}
                    </div>
                )}
                 { (gameStatus === GameStatus.INSUFFICIENT_FUNDS || (!isPostGameCooldownActive && gameStatus !== GameStatus.PLAYING && gameStatus !== GameStatus.READY)) || isAdminView && isGameEndModalOpen  }
                 {( (gameStatus === GameStatus.INSUFFICIENT_FUNDS || (!isPostGameCooldownActive && gameStatus !== GameStatus.PLAYING && gameStatus !== GameStatus.READY)) || (isAdminView && isGameEndModalOpen) ) && (
                    <div className="mt-6 flex justify-end space-x-2">
                        {gameStatus === GameStatus.INSUFFICIENT_FUNDS && !isAdminView && (
                            <Button onClick={handleOpenDepositModal} variant="secondary" animated={true}>Deposit Funds</Button>
                        )}
                        <Button onClick={handleCloseGameEndModal} variant={(gameStatus === GameStatus.INSUFFICIENT_FUNDS && !isAdminView) ? "secondary" : "primary"} animated={true} >
                            {(gameStatus === GameStatus.INSUFFICIENT_FUNDS && !isAdminView) ? "Close" : "Reset & Close"}
                        </Button>
                    </div>
                )}
            </> } >
        <div>{modalContent}</div>
      </Modal>

      {!isAdminView && (
        <DepositModal isOpen={isDepositModalOpen} onClose={handleCloseDepositModal} onDeposit={handleDeposit} currency={settings.currency} confirmButtonAnimated={true} />
      )}

      {!isAdminView && (
        <CashOutModal 
            isOpen={isCashOutModalOpen}
            onClose={handleCloseCashOutModal}
            onConfirmCashOut={handleConfirmCashOut}
            currency={settings.currency}
            maxAmount={currentWalletBalances.deposit}
            confirmButtonAnimated={true}
        />
      )}

      {!isAdminView && (
        <DashboardModal isOpen={isDashboardOpen} onClose={() => setIsDashboardOpen(false)} gameHistory={gameHistory} />
      )}

      {!isAdminView && (
        <footer className="mt-10 text-center text-sm text-slate-500">
            <p>&copy; {new Date().getFullYear()} EFADO Money Snake. All rights reserved.</p>
            <p className="text-xs">This game is for entertainment purposes only. Real money mode is simulated.</p>
        </footer>
      )}
    </div>
  );
};

export default GameClient;
