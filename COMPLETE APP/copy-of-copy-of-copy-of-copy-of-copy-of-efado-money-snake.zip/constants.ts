

import { Ball } from './types';

export const STAGE_WIDTH = 30; // cells
export const STAGE_HEIGHT = 20; // cells
export const GRID_SIZE = 20; // pixels per cell

export const INITIAL_SNAKE_LENGTH = 5;
export const GAME_SPEED_MS = 150; // milliseconds
export const SNAKE_MIN_LENGTH_THRESHOLD = 1; // If snake length is <= this, game over

export const CURRENCIES = [
  "NGN", // Nigerian Naira (Default)
  "USD", // US Dollar
  "EUR", // Euro
  "JPY", // Japanese Yen
  "GBP", // British Pound
  "AUD", // Australian Dollar
  "CAD", // Canadian Dollar
  "CHF", // Swiss Franc
  "CNY", // Chinese Yuan
  "INR", // Indian Rupee
  "BRL", // Brazilian Real
  "ZAR", // South African Rand
  "MXN", // Mexican Peso
  "KRW", // South Korean Won
  "RUB", // Russian Ruble
  "SAR", // Saudi Riyal
  "SGD", // Singapore Dollar
  "HKD", // Hong Kong Dollar
  "TWD", // New Taiwan Dollar
  "MYR", // Malaysian Ringgit
  "IDR", // Indonesian Rupiah
  "TRY", // Turkish Lira
  "VND", // Vietnamese Dong
  "CFA", // West African CFA Franc
];

export const STAKE_AMOUNTS = [
  100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 
  1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 5500, 6000, 6500, 7000, 7500, 8000, 
  8500, 9000, 9500, 10000, 11000, 11500, 12000, 12500, 13000, 13500, 14000, 14500, 15000, 
  15500, 16000, 16500, 17000, 17500, 18000, 18500, 19000, 19500, 20000, 30000, 40000, 
  50000, 60000, 70000, 80000, 90000, 100000, 110000, 120000, 130000, 140000, 150000, 
  160000, 170000, 180000, 190000, 200000, 300000, 400000, 500000, 600000, 700000, 
  800000, 900000, 1000000
].sort((a,b) => a - b); // Ensure sorted after combining and removing potential duplicates

export const MONEY_BALL_PERCENTAGES = [ 
  5, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33,
];

export const MIRROR_OBSTACLE_COUNT = 20;
export const MIRROR_OBSTACLE_COLOR = 'bg-slate-300'; 
export const MIRROR_OBSTACLE_FALL_SPEED = 1; 
export const OBSTACLE_PENALTY_PERCENTAGE = 0.10; 

export const BALL_COLORS = [ 
  'bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-400',
  'bg-purple-500', 'bg-pink-500', 'bg-indigo-500', 'bg-teal-500',
  'bg-orange-500', 'bg-lime-500', 'bg-cyan-500'
];

export const SNAKE_COLOR = 'bg-green-400';
export const WALL_COLOR = 'border-cyan-400';
export const STAGE_BG_COLOR = 'bg-slate-800';

export const KEY_CONTROLS: { [key: string]: string } = {
  ArrowUp: "UP",
  ArrowDown: "DOWN",
  ArrowLeft: "LEFT",
  ArrowRight: "RIGHT",
  w: "UP",
  s: "DOWN",
  a: "LEFT",
  d: "RIGHT",
};

export const INITIAL_DEPOSIT_WALLET_BALANCE = 0;
export const INITIAL_MOCK_WALLET_BALANCE = 100000;
export const INITIAL_ADMIN_WALLET_BALANCE = 0;

// New constants for game events and timer
export const WIN_TIME_LIMIT_SECONDS = 60;
export const AUTO_RESTART_DELAY_SECONDS = 20;
export const GAME_EVENT_EFFECT_DURATION = 2000; // ms, for overlays etc.

// Admin credentials (for simulation purposes)
export const ADMIN_USERNAME = "admin";
export const ADMIN_PASSWORD = "adminpassword"; // In a real app, this would be hashed and stored securely
