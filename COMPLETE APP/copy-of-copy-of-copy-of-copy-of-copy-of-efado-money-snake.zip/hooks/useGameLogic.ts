
import { useState, useEffect, useCallback } from 'react';
import { Position, Ball, Direction, GameStatus, GameSettings, BallType, WalletBalances, GameMode, GameEvent, GameEventPayloadMap } from '../types';
import {
  STAGE_WIDTH,
  STAGE_HEIGHT,
  INITIAL_SNAKE_LENGTH,
  GAME_SPEED_MS,
  MONEY_BALL_PERCENTAGES,
  BALL_COLORS,
  KEY_CONTROLS,
  MIRROR_OBSTACLE_COUNT,
  MIRROR_OBSTACLE_COLOR,
  OBSTACLE_PENALTY_PERCENTAGE,
  MIRROR_OBSTACLE_FALL_SPEED,
  SNAKE_MIN_LENGTH_THRESHOLD,
  WIN_TIME_LIMIT_SECONDS,
} from '../constants';

interface UseGameLogicProps {
  settings: GameSettings;
  isGamePausedForEffect: boolean;
  // Wallet interaction through functions passed from App.tsx via GameClient.tsx
  updateDepositWallet: (amountChange: number) => void; // Positive to add, negative to subtract
  updateMockWallet: (amountChange: number) => void;
  updateAdminWallet: (amountChange: number) => void;
  getWalletBalances: () => WalletBalances; // Function to get current global balances
}

const useGameLogic = ({ 
  settings, 
  isGamePausedForEffect,
  updateDepositWallet,
  updateMockWallet,
  updateAdminWallet,
  getWalletBalances
}: UseGameLogicProps) => {
  const [snake, setSnake] = useState<Position[]>([]);
  const [balls, setBalls] = useState<Ball[]>([]);
  const [direction, setDirection] = useState<Direction>(Direction.RIGHT);
  const [pendingDirection, setPendingDirection] = useState<Direction>(Direction.RIGHT);
  const [gamersWallet, setGamersWallet] = useState(0); // In-game score for the current round
  const [gameStatus, setGameStatus] = useState<GameStatus>(GameStatus.READY);
  const [lastGameEvent, setLastGameEvent] = useState<GameEvent | null>(null);
  const [stakeCommittedThisRound, setStakeCommittedThisRound] = useState(0);
  const [justLostSegments, setJustLostSegments] = useState(false);
  const [timeLeft, setTimeLeft] = useState(WIN_TIME_LIMIT_SECONDS);
  const [totalObstaclePenaltyThisRound, setTotalObstaclePenaltyThisRound] = useState(0);

  const emitGameEvent = <T extends keyof GameEventPayloadMap>(type: T, payload: GameEventPayloadMap[T]) => {
    setLastGameEvent({ id: Date.now().toString(), type, payload } as GameEvent);
  };

  const initializeGame = useCallback((currentStakeAmount: number) => {
    const initialSnakeHead: Position = { x: Math.floor(STAGE_WIDTH / 2), y: Math.floor(STAGE_HEIGHT / 2) };
    const initialSnake: Position[] = Array.from({ length: INITIAL_SNAKE_LENGTH }, (_, i) => ({ x: initialSnakeHead.x - i, y: initialSnakeHead.y }));
    setSnake(initialSnake);

    const newBalls: Ball[] = [];
    let occupiedPositions = new Set(initialSnake.map(p => `${p.x}-${p.y}`));
    MONEY_BALL_PERCENTAGES.forEach((percentage, index) => {
      let ballPos: Position;
      do {
        ballPos = { x: Math.floor(Math.random() * STAGE_WIDTH), y: Math.floor(Math.random() * STAGE_HEIGHT) };
      } while (occupiedPositions.has(`${ballPos.x}-${ballPos.y}`));
      occupiedPositions.add(`${ballPos.x}-${ballPos.y}`);
      newBalls.push({
        id: index, type: BallType.MONEY, position: ballPos, color: BALL_COLORS[index % BALL_COLORS.length],
        percentage, value: Math.round((currentStakeAmount * percentage) / 100 * 100) / 100, isEaten: false,
      });
    });
    for (let i = 0; i < MIRROR_OBSTACLE_COUNT; i++) {
      newBalls.push({
        id: MONEY_BALL_PERCENTAGES.length + i, type: BallType.MIRROR_OBSTACLE,
        position: { x: Math.floor(Math.random() * STAGE_WIDTH), y: 0 },
        color: MIRROR_OBSTACLE_COLOR, percentage: 0, value: 0, isEaten: false, hasLanded: false,
        targetY: Math.floor(Math.random() * STAGE_HEIGHT),
      });
    }
    setBalls(newBalls);
    setGamersWallet(0);
    setDirection(Direction.RIGHT);
    setPendingDirection(Direction.RIGHT);
    setLastGameEvent(null);
    setJustLostSegments(false);
    setTimeLeft(WIN_TIME_LIMIT_SECONDS);
    setTotalObstaclePenaltyThisRound(0);
  }, []);

  useEffect(() => {
     if (gameStatus === GameStatus.READY || gameStatus === GameStatus.INSUFFICIENT_FUNDS) {
        initializeGame(settings.stakeAmount);
     }
  }, [settings.stakeAmount, settings.currency, settings.gameMode, initializeGame, gameStatus]);

  const startGame = () => {
    const currentBalances = getWalletBalances();
    if (settings.gameMode === GameMode.REAL) {
      if (currentBalances.deposit < settings.stakeAmount) {
        setGameStatus(GameStatus.INSUFFICIENT_FUNDS);
        emitGameEvent('GAME_OVER', { reason: 'collision', finalScore: 0, stakeCommitted: settings.stakeAmount, totalObstaclePenalty: 0, refundApplied: 0 });
        return;
      }
      updateDepositWallet(-settings.stakeAmount); // Deduct stake
      updateAdminWallet(settings.stakeAmount);    // Admin receives stake
    } else { // Mock Game
      if (currentBalances.mock < settings.stakeAmount) {
        setGameStatus(GameStatus.INSUFFICIENT_FUNDS);
        emitGameEvent('GAME_OVER', { reason: 'collision', finalScore: 0, stakeCommitted: settings.stakeAmount, totalObstaclePenalty: 0, refundApplied: 0 });
        return;
      }
      updateMockWallet(-settings.stakeAmount); // Deduct stake
      // No real admin wallet involvement for mock game stake collection at this point
    }
    setStakeCommittedThisRound(settings.stakeAmount);
    initializeGame(settings.stakeAmount);
    setGameStatus(GameStatus.PLAYING);
  };

  const moveSnake = () => {
    if (justLostSegments) setJustLostSegments(false);
    setSnake(prevSnake => {
      if (prevSnake.length === 0) return [];
      const newSnake = [...prevSnake];
      let head = { ...newSnake[0] };
      setDirection(pendingDirection);
      switch (pendingDirection) {
        case Direction.UP: head.y -= 1; break;
        case Direction.DOWN: head.y += 1; break;
        case Direction.LEFT: head.x -= 1; break;
        case Direction.RIGHT: head.x += 1; break;
      }
      newSnake.unshift(head);
      const eatenBallIndex = balls.findIndex(b => !b.isEaten && b.position.x === head.x && b.position.y === head.y);
      if (eatenBallIndex !== -1) {
        const eatenBall = balls[eatenBallIndex];
        if (eatenBall.type === BallType.MONEY) {
          setGamersWallet(prevScore => prevScore + eatenBall.value);
          emitGameEvent('MONEY_EATEN', { value: eatenBall.value, percentage: eatenBall.percentage, position: eatenBall.position });
        } else if (eatenBall.type === BallType.MIRROR_OBSTACLE) {
          const walletPenalty = gamersWallet * OBSTACLE_PENALTY_PERCENTAGE;
          setGamersWallet(prevScore => Math.max(0, prevScore - walletPenalty));
          setTotalObstaclePenaltyThisRound(prev => prev + walletPenalty);
          let lengthReduction = 0;
          const currentLength = newSnake.length - 1; 
          if (currentLength > SNAKE_MIN_LENGTH_THRESHOLD) {
            const segmentsToLose = Math.max(1, Math.floor(currentLength * OBSTACLE_PENALTY_PERCENTAGE));
            lengthReduction = segmentsToLose;
            const newSnakeLengthAfterHit = Math.max(SNAKE_MIN_LENGTH_THRESHOLD, currentLength - segmentsToLose);
            setJustLostSegments(true); 
            while(newSnake.length > newSnakeLengthAfterHit + 1) newSnake.pop();
          }
          emitGameEvent('OBSTACLE_HIT', { scorePenalty: walletPenalty, lengthReduction, position: eatenBall.position });
        }
        setBalls(prevBalls => prevBalls.map((b, i) => (i === eatenBallIndex ? { ...b, isEaten: true } : b)));
        return newSnake; 
      } else {
        if (!justLostSegments) newSnake.pop();
      }
      return newSnake;
    });
  };

  const moveBalls = () => {
    setBalls(prevBalls => prevBalls.map(ball => {
      if (ball.isEaten) return ball;
      let newPos = {...ball.position};
      if (ball.type === BallType.MIRROR_OBSTACLE && !ball.hasLanded) {
        newPos.y += MIRROR_OBSTACLE_FALL_SPEED;
        if (newPos.y >= (ball.targetY ?? STAGE_HEIGHT -1) || newPos.y >= STAGE_HEIGHT -1 ) {
          newPos.y = Math.min(ball.targetY ?? STAGE_HEIGHT -1, STAGE_HEIGHT - 1);
          return {...ball, position: newPos, hasLanded: true};
        }
        return {...ball, position: newPos};
      } else if (ball.type === BallType.MONEY) { 
        const moveAttemptLimit = 5; let attempts = 0;
        const snakeHead = snake.length > 0 ? snake[0] : null;
        do {
          const randomMove = Math.floor(Math.random() * 5); 
          let tempPos = {...ball.position};
          switch(randomMove) {
            case 1: tempPos.y = Math.max(0, tempPos.y - 1); break; 
            case 2: tempPos.y = Math.min(STAGE_HEIGHT - 1, tempPos.y + 1); break; 
            case 3: tempPos.x = Math.max(0, tempPos.x - 1); break; 
            case 4: tempPos.x = Math.min(STAGE_WIDTH - 1, tempPos.x + 1); break; 
            default: break; 
          }
          if (snakeHead && tempPos.x === snakeHead.x && tempPos.y === snakeHead.y) {
            if (attempts < moveAttemptLimit) { attempts++; continue; }
            else { tempPos = {...ball.position}; } 
          }
          newPos = tempPos; break;
        } while (attempts < moveAttemptLimit);
        newPos.x = Math.max(0, Math.min(STAGE_WIDTH - 1, newPos.x));
        newPos.y = Math.max(0, Math.min(STAGE_HEIGHT - 1, newPos.y));
        return {...ball, position: newPos};
      }
      return ball; 
    }));
  };

  useEffect(() => {
    if (gameStatus !== GameStatus.PLAYING || isGamePausedForEffect) return;
    const gameTick = setInterval(() => {
      if (!isGamePausedForEffect) {
        moveSnake(); moveBalls();
        setTimeLeft(prev => {
          if (prev <= (GAME_SPEED_MS / 1000)) { setGameStatus(GameStatus.TIME_UP); return 0; }
          return prev - (GAME_SPEED_MS / 1000);
        });
      }
    }, GAME_SPEED_MS);
    return () => clearInterval(gameTick);
  }, [gameStatus, pendingDirection, isGamePausedForEffect]);

  useEffect(() => {
    if (gameStatus !== GameStatus.PLAYING && gameStatus !== GameStatus.TIME_UP) return;
    if (isGamePausedForEffect) return;

    let newDeterminedStatus: GameStatus | null = null;
    let gameOverReasonDetail: GameEventPayloadMap['GAME_OVER']['reason'] = 'collision';

    if (gameStatus === GameStatus.PLAYING) {
      if (snake.length === 0) { newDeterminedStatus = GameStatus.GAME_OVER; gameOverReasonDetail = 'too_short'; } 
      else {
        const head = snake[0];
        if (head.x < 0 || head.x >= STAGE_WIDTH || head.y < 0 || head.y >= STAGE_HEIGHT) { newDeterminedStatus = GameStatus.GAME_OVER; gameOverReasonDetail = 'collision'; } 
        else {
          for (let i = 1; i < snake.length; i++) { if (snake[i].x === head.x && snake[i].y === head.y) { newDeterminedStatus = GameStatus.GAME_OVER; gameOverReasonDetail = 'collision'; break; } }
        }
        if (!newDeterminedStatus && snake.length > 0 && snake.length <= SNAKE_MIN_LENGTH_THRESHOLD) { newDeterminedStatus = GameStatus.GAME_OVER; gameOverReasonDetail = 'too_short'; }
        const allMoneyBalls = balls.filter(b => b.type === BallType.MONEY);
        if (!newDeterminedStatus && allMoneyBalls.length > 0 && allMoneyBalls.every(ball => ball.isEaten)) {
          newDeterminedStatus = timeLeft > 0 ? GameStatus.WON : GameStatus.TIME_UP;
        }
      }
    }
    if (gameStatus === GameStatus.TIME_UP && !newDeterminedStatus) {
      const allMoneyBalls = balls.filter(b => b.type === BallType.MONEY);
      newDeterminedStatus = (allMoneyBalls.length > 0 && allMoneyBalls.every(ball => ball.isEaten)) ? GameStatus.WON : GameStatus.TIME_UP;
    }

    if (newDeterminedStatus) {
      setGameStatus(newDeterminedStatus);
      const stake = stakeCommittedThisRound;
      const winnings = gamersWallet;
      const obstacleLosses = totalObstaclePenaltyThisRound;
      const userDefinedTotalLoss = obstacleLosses + Math.max(0, stake - winnings);
      let refundAmount = 0;
      if (userDefinedTotalLoss <= stake / 2) refundAmount = 0.10 * stake;
      const amountToReturnToPlayer = winnings + refundAmount;

      if (settings.gameMode === GameMode.REAL) {
        updateDepositWallet(amountToReturnToPlayer);    // Player receives payout
        updateAdminWallet(-amountToReturnToPlayer);   // Admin pays out
      } else { // GameMode.MOCK
        updateMockWallet(amountToReturnToPlayer);       // Player mock wallet receives payout
        // No direct admin wallet change for mock game payout from this logic
      }

      if (newDeterminedStatus === GameStatus.WON) {
        emitGameEvent('GAME_WON', { finalScore: winnings, timeLeft: Math.max(0, timeLeft), totalObstaclePenalty: obstacleLosses, refundApplied: refundAmount });
      } else { // GAME_OVER or TIME_UP
        const reason = newDeterminedStatus === GameStatus.TIME_UP ? 'time_up' : gameOverReasonDetail;
        emitGameEvent('GAME_OVER', { reason: reason, finalScore: winnings, stakeCommitted: stake, totalObstaclePenalty: obstacleLosses, refundApplied: refundAmount });
      }
    }
  }, [snake, balls, gameStatus, settings, gamersWallet, stakeCommittedThisRound, timeLeft, totalObstaclePenaltyThisRound, isGamePausedForEffect, updateDepositWallet, updateMockWallet, updateAdminWallet]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (isGamePausedForEffect) return;
    const newKey = KEY_CONTROLS[e.key];
    if (!newKey) return;
    setPendingDirection(prevPendingDir => {
      let newDir = prevPendingDir;
      const canTurnImmediately = snake.length <= 2; 
      switch (newKey) {
        case "UP": if (direction !== Direction.DOWN || canTurnImmediately) newDir = Direction.UP; break;
        case "DOWN": if (direction !== Direction.UP || canTurnImmediately) newDir = Direction.DOWN; break;
        case "LEFT": if (direction !== Direction.RIGHT || canTurnImmediately) newDir = Direction.LEFT; break;
        case "RIGHT": if (direction !== Direction.LEFT || canTurnImmediately) newDir = Direction.RIGHT; break;
      }
      return newDir;
    });
  }, [direction, snake.length, isGamePausedForEffect]);

  useEffect(() => {
    if (gameStatus === GameStatus.PLAYING) window.addEventListener('keydown', handleKeyDown);
    else window.removeEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameStatus, handleKeyDown]);

  const resetGame = () => {
    initializeGame(settings.stakeAmount); 
    setGameStatus(GameStatus.READY);
    setLastGameEvent(null); 
  };

  return { snake, balls, score: gamersWallet, gameStatus, lastGameEvent, startGame, resetGame, timeLeft };
};

export default useGameLogic;
