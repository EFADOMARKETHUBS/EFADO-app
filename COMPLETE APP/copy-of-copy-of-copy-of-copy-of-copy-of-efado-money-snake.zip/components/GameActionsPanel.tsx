
import React from 'react';
import { GameSettings, GameStatus } from '../types'; 
import { STAKE_AMOUNTS } from '../constants';
import Button from './Button';

interface GameActionsPanelProps {
  stakeAmount: number;
  onStakeAmountChange: (value: number) => void;
  onStartGame: () => void;
  gameStatusText: string; 
  stakeSelectorDisabled: boolean; 
  startButtonDisabled: boolean;   
  startButtonAnimated?: boolean; // New prop for animation
}

const GameActionsPanel: React.FC<GameActionsPanelProps> = ({ 
  stakeAmount, 
  onStakeAmountChange, 
  onStartGame, 
  gameStatusText, 
  stakeSelectorDisabled,
  startButtonDisabled,
  startButtonAnimated = false // Default to false
}) => {
  const buttonText = 
    gameStatusText === GameStatus[GameStatus.READY].replace(/_/g, ' ') || 
    gameStatusText === GameStatus[GameStatus.INSUFFICIENT_FUNDS].replace(/_/g, ' ')
    ? 'Start Game' 
    : 'Restart Game';

  return (
    <div className="mt-4 p-4 bg-slate-700/80 rounded-lg shadow-md flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 sm:space-x-4">
      <div>
        <label htmlFor="stakeAmountGameAction" className="block text-sm font-medium text-cyan-300 mb-1 text-center sm:text-left">
          Stake Amount
        </label>
        <select
          id="stakeAmountGameAction"
          value={stakeAmount}
          onChange={(e) => onStakeAmountChange(parseFloat(e.target.value))}
          disabled={stakeSelectorDisabled} 
          className="w-full sm:w-auto bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500 disabled:opacity-70"
        >
          {STAKE_AMOUNTS.map(sa => <option key={sa} value={sa}>{sa}</option>)}
        </select>
      </div>
      
      <Button 
        onClick={onStartGame} 
        disabled={startButtonDisabled} 
        className="w-full sm:w-auto px-6 py-2.5 text-base"
        variant="primary"
        animated={startButtonAnimated} // Apply animation
      >
        {buttonText}
      </Button>
    </div>
  );
};

export default GameActionsPanel;