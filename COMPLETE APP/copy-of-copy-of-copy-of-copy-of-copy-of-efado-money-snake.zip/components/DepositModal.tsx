
import React, { useState } from 'react';
import Modal from './Modal';
import Button from './Button';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDeposit: (amount: number) => void;
  currency: string;
  confirmButtonAnimated?: boolean; // New prop
}

type DepositMethod = "ussd" | "external_wallet" | "bank_transfer";

const DepositModal: React.FC<DepositModalProps> = ({ isOpen, onClose, onDeposit, currency, confirmButtonAnimated = false }) => {
  const [amount, setAmount] = useState<string>("");
  const [selectedMethod, setSelectedMethod] = useState<DepositMethod>("ussd");
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFeedbackMessage(null);
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      setAmount(value);
    }
  };

  const handleSubmitDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      setFeedbackMessage("Please enter a valid positive amount.");
      return;
    }
    onDeposit(numericAmount);
    setFeedbackMessage(`Successfully deposited ${numericAmount.toFixed(2)} ${currency}.`);
    setAmount(""); 
  };
  
  const renderDepositMethodFields = () => {
    switch(selectedMethod) {
      case "ussd":
        return (
          <div className="space-y-2 text-sm text-slate-300">
            <p>Dial the following code on your mobile phone:</p>
            <p className="font-mono bg-slate-700 p-2 rounded">*123*000*{amount || 'AMOUNT'}*{'REF123'}#</p>
            <p>Then confirm the transaction on your phone.</p>
          </div>
        );
      case "external_wallet":
        return (
          <div className="space-y-2 text-sm text-slate-300">
            <p>Transfer {amount || 'AMOUNT'} {currency} to the following wallet address:</p>
            <p className="font-mono bg-slate-700 p-2 rounded break-all">EFADOMONEYSNAKEWALLETADDRESSXYZ123ABC</p>
            <p>Ensure you are on the correct network.</p>
          </div>
        );
      case "bank_transfer":
        return (
          <div className="space-y-2 text-sm text-slate-300">
            <p>Transfer {amount || 'AMOUNT'} {currency} to:</p>
            <p><strong>Bank:</strong> EFADO Financial</p>
            <p><strong>Account Number:</strong> 1234567890</p>
            <p><strong>Reference:</strong> SNAKE-{Date.now().toString().slice(-6)}</p>
          </div>
        );
      default:
        return null;
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Deposit to Real Wallet (${currency})`} showCloseButton={true}>
      <form onSubmit={handleSubmitDeposit} className="space-y-4">
        <div>
          <label htmlFor="depositAmount" className="block text-sm font-medium text-cyan-300 mb-1">
            Amount ({currency})
          </label>
          <input
            type="text"
            id="depositAmount"
            value={amount}
            onChange={handleAmountChange}
            placeholder="e.g., 50.00"
            className="w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500"
            aria-describedby="amount-feedback"
          />
        </div>

        <div>
            <label className="block text-sm font-medium text-cyan-300 mb-1">Payment Method</label>
            <div className="flex space-x-2">
                {(["ussd", "external_wallet", "bank_transfer"] as DepositMethod[]).map(method => (
                    <Button 
                        type="button"
                        key={method}
                        variant={selectedMethod === method ? 'primary' : 'secondary'}
                        onClick={() => { setSelectedMethod(method); setFeedbackMessage(null); }}
                        className="flex-1 text-xs sm:text-sm"
                    >
                        {method.replace('_', ' ').toUpperCase()}
                    </Button>
                ))}
            </div>
        </div>

        <div className="p-3 bg-slate-700/50 rounded-md min-h-[80px]">
            {renderDepositMethodFields()}
        </div>
        
        {feedbackMessage && (
          <p id="amount-feedback" className={`text-sm ${feedbackMessage.startsWith("Successfully") ? 'text-green-400' : 'text-red-400'}`} role="alert">
            {feedbackMessage}
          </p>
        )}

        <div className="flex justify-end pt-2">
          <Button type="submit" variant="primary" disabled={!amount || parseFloat(amount) <= 0} animated={confirmButtonAnimated}>
            Confirm Mock Deposit
          </Button>
        </div>
        <p className="text-xs text-slate-400 text-center">This is a simulation. No real money will be transferred.</p>
      </form>
    </Modal>
  );
};

export default DepositModal;