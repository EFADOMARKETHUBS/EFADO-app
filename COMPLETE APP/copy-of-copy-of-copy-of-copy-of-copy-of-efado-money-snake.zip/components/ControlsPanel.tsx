
import React from 'react';
import { GameMode, GameSettings } from '../types';
import { CURRENCIES } from '../constants';

interface ControlsPanelProps {
  settings: GameSettings;
  onSettingsChange: <K extends keyof GameSettings>(key: K, value: GameSettings[K]) => void;
  disabled: boolean; 
}

const ControlsPanel: React.FC<ControlsPanelProps> = ({ settings, onSettingsChange, disabled }) => {
  return (
    <div className="p-4 bg-slate-700 rounded-lg shadow-md space-y-4 md:space-y-0 md:flex md:space-x-4 md:items-end">
      {/* Currency Selector */}
      <div>
        <label htmlFor="currency" className="block text-sm font-medium text-cyan-300 mb-1">Currency</label>
        <select
          id="currency"
          value={settings.currency}
          onChange={(e) => onSettingsChange('currency', e.target.value)}
          disabled={disabled} // Controlled by App.tsx
          className="w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500 disabled:opacity-70"
        >
          {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Game Mode Selector */}
      <div>
        <label htmlFor="gameMode" className="block text-sm font-medium text-cyan-300 mb-1">Game Mode</label>
        <select
          id="gameMode"
          value={settings.gameMode}
          onChange={(e) => onSettingsChange('gameMode', e.target.value as GameMode)}
          disabled={disabled} // Controlled by App.tsx
          className="w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500 disabled:opacity-70"
        >
          {Object.values(GameMode).map(gm => <option key={gm} value={gm}>{gm}</option>)}
        </select>
      </div>
    </div>
  );
};

export default ControlsPanel;
