import React from 'react';
import Modal from './Modal';
import Button from './Button';
import { GameRecord, GameStatus, GameMode } from '../types';

interface DashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  gameHistory: GameRecord[];
}

const DashboardModal: React.FC<DashboardModalProps> = ({ isOpen, onClose, gameHistory }) => {
  const formatDateTime = (date: Date | string) => {
    return new Date(date).toLocaleString();
  };

  const getStatusText = (record: GameRecord): string => {
    switch (record.status) {
      case GameStatus.WON:
        return `Won (Time: ${record.timeLeft?.toFixed(0)}s)`;
      case GameStatus.GAME_OVER:
        return `Lost: ${record.reason?.replace(/_/g, ' ') || 'Unknown'}`;
      case GameStatus.TIME_UP:
        return "Lost: Time Up";
      default:
        return GameStatus[record.status]?.replace(/_/g, ' ') || "Unknown";
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Game Dashboard" showCloseButton={true}
      customFooter={
        <div className="mt-6 flex justify-end">
          <Button onClick={onClose} variant="primary">Close</Button>
        </div>
      }
    >
      <div className="text-gray-300 max-h-[70vh] overflow-y-auto">
        <p className="mb-4 text-lg">Total Games Played by You: <span className="font-bold text-cyan-400">{gameHistory.length}</span></p>
        {gameHistory.length === 0 ? (
          <p>No games played yet in this session.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-600 table-fixed">
              <thead className="bg-slate-700">
                <tr>
                  <th scope="col" className="w-[12%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">Date & Time</th>
                  <th scope="col" className="w-[10%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">User</th>
                  <th scope="col" className="w-[12%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">Status</th>
                  <th scope="col" className="w-[7%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">Mode</th>
                  <th scope="col" className="w-[8%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">Stake</th>
                  <th scope="col" className="w-[10%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">Winnings (Gross)</th>
                  <th scope="col" className="w-[8%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">Refund Applied</th>
                  <th scope="col" className="w-[10%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">Player Total Payout</th>
                  <th scope="col" className="w-[10%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">Player Net vs Stake</th>
                  <th scope="col" className="w-[10%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">Admin Net Profit (Real)</th>
                  <th scope="col" className="w-[10%] px-3 py-2 text-left text-xs font-medium text-cyan-300 uppercase tracking-wider">Lost (Obstacles)</th>
                </tr>
              </thead>
              <tbody className="bg-slate-800 divide-y divide-slate-700">
                {gameHistory.map((record) => {
                  const playerTotalPayout = record.finalScore + record.refundApplied;
                  const playerNetVsStake = playerTotalPayout - record.stakeAmount;
                  return (
                    <tr key={record.id}>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-300 truncate" title={formatDateTime(record.gameEndTime)}>{formatDateTime(record.gameEndTime)}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-300 truncate" title={record.userName}>{record.userName}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-300 truncate" title={getStatusText(record)}>{getStatusText(record)}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-300">{record.gameMode}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-300">{record.stakeAmount.toFixed(2)} {record.currency}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-300">{record.finalScore.toFixed(2)}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-300">
                        {record.refundApplied > 0 ? `${record.refundApplied.toFixed(2)} ${record.currency}` : 'N/A'}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-300">{playerTotalPayout.toFixed(2)}</td>
                      <td className={`px-3 py-2 whitespace-nowrap text-sm ${playerNetVsStake >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {playerNetVsStake.toFixed(2)}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-300">
                        {record.gameMode === GameMode.REAL ? record.amountLostToAdmin.toFixed(2) : 'N/A'}
                      </td>
                      <td className="px-3 py-2 whitespace-nowrap text-sm text-slate-300">{record.amountLostToObstacles.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </Modal>
  );
};

export default DashboardModal;