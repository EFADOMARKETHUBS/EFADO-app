
import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'danger';
  className?: string;
  animated?: boolean; // New prop for animation
}

const Button: React.FC<ButtonProps> = ({ children, variant = 'primary', className = '', animated = false, ...props }) => {
  const baseStyle = "px-4 py-2 rounded-md font-semibold focus:outline-none focus:ring-2 focus:ring-opacity-75 transition-colors duration-150";
  
  let variantStyle = "";
  switch (variant) {
    case 'primary':
      variantStyle = "bg-blue-600 hover:bg-blue-700 text-white focus:ring-blue-500";
      break;
    case 'secondary':
      variantStyle = "bg-gray-600 hover:bg-gray-700 text-white focus:ring-gray-500";
      break;
    case 'danger':
      variantStyle = "bg-red-600 hover:bg-red-700 text-white focus:ring-red-500";
      break;
  }

  const animationClass = animated ? 'button-bounce-loop' : '';

  return (
    <button className={`${baseStyle} ${variantStyle} ${animationClass} ${className}`} {...props}>
      {children}
    </button>
  );
};

export default Button;