
import React, { useState } from 'react';
import Button from '../Button';
import { User, GameMode, WalletBalances } from '../../types';
import GameClient from '../../GameClient';
import AdminWithdrawModal from './AdminWithdrawModal'; // New

interface AdminDashboardProps {
  user: User;
  onLogout: () => void;
  adminProfitWalletBalance: number;
  onAdminWithdraw: (amount: number, details: any) => boolean;
  // Props for GameClient in mock mode
  initialMockBalanceForGameClient: number;
  updateGlobalMockWalletForGameClient: (amount: number) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  user, 
  onLogout, 
  adminProfitWalletBalance, 
  onAdminWithdraw,
  initialMockBalanceForGameClient,
  updateGlobalMockWalletForGameClient
}) => {
  const [showMockGame, setShowMockGame] = useState(false);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);

  const handleConfirmWithdraw = (amount: number, details: any) => {
    const success = onAdminWithdraw(amount, details);
    if (success) {
      setIsWithdrawModalOpen(false); // Close modal on successful withdrawal
    }
    return success; // Return success status for modal's internal feedback
  };
  
  // Construct partial WalletBalances for the GameClient in mock mode
  // The crucial part is that its admin wallet for game logic is separate (usually starts at 0 for mock games)
  // and its deposit wallet is irrelevant/disabled.
  const mockGameInitialBalances: WalletBalances = {
    deposit: 0, // Mock game client for admin shouldn't use real deposit
    mock: initialMockBalanceForGameClient,
    admin: 0 // The admin wallet *within* the mock game instance starts at 0
  };

  return (
    <div className="min-h-screen bg-slate-900 text-gray-100 p-4 sm:p-6 lg:p-8">
      <header className="flex justify-between items-center mb-8 pb-4 border-b border-slate-700">
        <div>
          <h1 className="text-3xl sm:text-4xl font-bold text-cyan-400 neon-text">Admin Dashboard</h1>
          <p className="text-slate-300">Welcome, {user.name} ({user.username})</p>
        </div>
        <Button onClick={onLogout} variant="danger" animated>
          Logout
        </Button>
      </header>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-cyan-300 mb-4">Admin Profit Wallet</h2>
        <div className="bg-slate-800 p-6 rounded-lg shadow-lg flex flex-col sm:flex-row justify-between items-center">
          <div>
            <p className="text-slate-300 text-lg">Current Total Profit:</p>
            <p className="text-3xl font-bold text-green-400">
              {adminProfitWalletBalance.toFixed(2)} <span className="text-base text-slate-400">CUR</span> {/* Assuming a generic currency display */}
            </p>
          </div>
          <Button
            onClick={() => setIsWithdrawModalOpen(true)}
            variant="primary"
            className="mt-4 sm:mt-0 px-6 py-3 text-lg"
            animated
            disabled={adminProfitWalletBalance <= 0}
          >
            Withdraw Funds
          </Button>
        </div>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-cyan-300 mb-4">Game Management</h2>
        <div className="bg-slate-800 p-4 rounded-lg shadow-lg">
          <p className="mb-3 text-slate-300">
            Launch the game in Mock Mode to test mechanics. This uses a separate mock wallet and does not affect real admin profits.
          </p>
          <Button onClick={() => setShowMockGame(prev => !prev)} variant="primary" className="px-6 py-3 text-lg" animated>
            {showMockGame ? 'Hide Mock Game Interface' : 'Launch Mock Game Interface'}
          </Button>
        </div>
      </section>

      {showMockGame && (
        <section className="my-8 p-4 bg-slate-800 rounded-lg shadow-xl border border-cyan-500/50">
          <h3 className="text-xl font-semibold text-cyan-400 mb-4 text-center">Mock Game Playground (Admin View)</h3>
          <div className="game-client-wrapper overflow-hidden rounded-md" style={{ maxHeight: '80vh', overflowY: 'auto' }}>
            <GameClient 
              currentUser={user} 
              onLogout={() => { /* Logout handled by main dashboard */ }} 
              isAdminView={true} 
              forcedGameMode={GameMode.MOCK}
              initialWalletBalances={mockGameInitialBalances}
              // For a mock game run by admin, deposit and admin wallet updates shouldn't affect global real ones.
              // Mock wallet updates can optionally affect a global mock wallet if desired.
              updateGlobalDepositWallet={() => console.log("Admin mock game: Deposit update suppressed")}
              updateGlobalMockWallet={updateGlobalMockWalletForGameClient} // Admin's mock game can use the global mock wallet
              updateGlobalAdminWallet={() => console.log("Admin mock game: Admin profit update suppressed")}
              onPlayerCashOut={() => { console.log("Admin mock game: Player cashout suppressed"); return false;}}
            />
          </div>
        </section>
      )}

      {/* Placeholder for future admin sections */}
      <section className="mb-8">
        <h2 className="text-2xl font-semibold text-cyan-300 mb-4">User Management (Placeholder)</h2>
        <div className="bg-slate-800 p-6 rounded-lg shadow-lg">
          <p className="text-slate-400">User list and management tools will appear here.</p>
        </div>
      </section>
      <section>
        <h2 className="text-2xl font-semibold text-cyan-300 mb-4">Game Records Overview (Placeholder)</h2>
        <div className="bg-slate-800 p-6 rounded-lg shadow-lg">
          <p className="text-slate-400">A summary or list of all game records will appear here.</p>
        </div>
      </section>

      <AdminWithdrawModal
        isOpen={isWithdrawModalOpen}
        onClose={() => setIsWithdrawModalOpen(false)}
        onConfirmWithdraw={handleConfirmWithdraw}
        currency={"CUR"} // Generic currency for admin display
        maxAmount={adminProfitWalletBalance}
        confirmButtonAnimated={true}
      />

      <footer className="mt-12 text-center text-sm text-slate-500">
        <p>EFADO Money Snake Admin Panel &copy; {new Date().getFullYear()}</p>
      </footer>
    </div>
  );
};

export default AdminDashboard;
