
import React, { useState, useEffect } from 'react';
import Modal from '../Modal';
import Button from '../Button';

interface AdminWithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmWithdraw: (amount: number, details: { method: string, identifier: string }) => boolean; // Returns true on success
  currency: string; // Admin wallet currency (can be generic like "CUR")
  maxAmount: number; // Admin's total profit balance
  confirmButtonAnimated?: boolean;
}

type WithdrawMethod = "admin_bank_transfer" | "admin_crypto_wallet";

const AdminWithdrawModal: React.FC<AdminWithdrawModalProps> = ({ 
  isOpen, 
  onClose, 
  onConfirmWithdraw, 
  currency, 
  maxAmount,
  confirmButtonAnimated = false 
}) => {
  const [amount, setAmount] = useState<string>("");
  const [selectedMethod, setSelectedMethod] = useState<WithdrawMethod>("admin_bank_transfer");
  const [identifier, setIdentifier] = useState<string>(""); // Bank account or wallet address
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setAmount("");
      setIdentifier("");
      setFeedbackMessage(null);
    }
  }, [isOpen, selectedMethod]);

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFeedbackMessage(null);
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      setAmount(value);
    }
  };

  const handleSubmitWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseFloat(amount);

    if (isNaN(numericAmount) || numericAmount <= 0) {
      setFeedbackMessage("Please enter a valid positive amount.");
      return;
    }
    if (numericAmount > maxAmount) {
      setFeedbackMessage(`Amount exceeds available balance of ${maxAmount.toFixed(2)} ${currency}.`);
      return;
    }
    if (!identifier.trim()) {
      setFeedbackMessage(`Please enter the ${selectedMethod === "admin_bank_transfer" ? "bank account details" : "wallet address"} for withdrawal.`);
      return;
    }

    const success = onConfirmWithdraw(numericAmount, { method: selectedMethod, identifier });
    if (success) {
      setFeedbackMessage(`Successfully initiated withdrawal of ${numericAmount.toFixed(2)} ${currency}.`);
      // Optionally close or reset form, parent handles actual balance update
    } else {
      setFeedbackMessage("Withdrawal failed. Please try again or check the balance.");
    }
  };
  
  const getIdentifierPlaceholder = () => {
    switch(selectedMethod) {
      case "admin_bank_transfer": return "e.g., Admin Bank - Account Number";
      case "admin_crypto_wallet": return "e.g., Admin Crypto Wallet Address";
      default: return "Withdrawal Details";
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Withdraw from Admin Wallet (${currency})`} showCloseButton={true}>
      <form onSubmit={handleSubmitWithdraw} className="space-y-4">
        <div>
          <label htmlFor="withdrawAmount" className="block text-sm font-medium text-cyan-300 mb-1">
            Amount to Withdraw ({currency})
          </label>
          <input
            type="text"
            id="withdrawAmount"
            value={amount}
            onChange={handleAmountChange}
            placeholder={`Max: ${maxAmount.toFixed(2)}`}
            className="w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500"
            aria-describedby="withdraw-amount-feedback"
          />
          <p className="text-xs text-slate-400 mt-1">Available to withdraw: {maxAmount.toFixed(2)} {currency}</p>
        </div>

        <div>
            <label className="block text-sm font-medium text-cyan-300 mb-1">Withdrawal Method</label>
            <div className="flex space-x-2">
                {(["admin_bank_transfer", "admin_crypto_wallet"] as WithdrawMethod[]).map(method => (
                    <Button 
                        type="button"
                        key={method}
                        variant={selectedMethod === method ? 'primary' : 'secondary'}
                        onClick={() => setSelectedMethod(method)}
                        className="flex-1 text-xs sm:text-sm"
                    >
                        {method.replace('admin_', '').replace('_', ' ').toUpperCase()}
                    </Button>
                ))}
            </div>
        </div>

        <div>
          <label htmlFor="withdrawIdentifier" className="block text-sm font-medium text-cyan-300 mb-1">
            {selectedMethod === "admin_bank_transfer" ? "Recipient Bank Details (Simulated)" : "Recipient Wallet Address (Simulated)"}
          </label>
          <input
            type="text"
            id="withdrawIdentifier"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            placeholder={getIdentifierPlaceholder()}
            className="w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500"
          />
        </div>
        
        {feedbackMessage && (
          <p id="withdraw-amount-feedback" className={`text-sm ${feedbackMessage.startsWith("Successfully") ? 'text-green-400' : 'text-red-400'}`} role="alert">
            {feedbackMessage}
          </p>
        )}

        <div className="flex justify-end pt-2">
          <Button 
            type="submit" 
            variant="primary" 
            disabled={!amount || parseFloat(amount) <= 0 || parseFloat(amount) > maxAmount || !identifier.trim()} 
            animated={confirmButtonAnimated}
          >
            Confirm Withdrawal
          </Button>
        </div>
        <p className="text-xs text-slate-400 text-center">This is a simulation. No real money will be transferred.</p>
      </form>
    </Modal>
  );
};

export default AdminWithdrawModal;
