import React, { useState } from 'react';
import { GameSettings, GameStatus, GameMode } from '../types';
import { 
  MONEY_BALL_PERCENTAGES, 
  WIN_TIME_LIMIT_SECONDS, 
  OBSTACLE_PENALTY_PERCENTAGE, 
  SNAKE_MIN_LENGTH_THRESHOLD,
  INITIAL_SNAKE_LENGTH,
  MIRROR_OBSTACLE_COUNT
} from '../constants';

interface CollapsibleGameInfoProps {
  gameStatus: GameStatus;
  isGamePausedForEffect: boolean;
  isPostGameCooldownActive: boolean;
  autoRestartCountdown: number;
  timeLeft: number;
  score: number;
  settings: GameSettings;
  className?: string;
}

const CollapsibleGameInfo: React.FC<CollapsibleGameInfoProps> = ({
  gameStatus,
  isGamePausedForEffect,
  isPostGameCooldownActive,
  autoRestartCountdown,
  timeLeft,
  score,
  settings,
  className = ''
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleOpen = () => setIsOpen(!isOpen);

  const displayedStatusText = GameStatus[gameStatus]?.replace(/_/g, ' ') || 'Unknown';

  return (
    <div className={`w-full bg-slate-700 rounded-lg shadow-md ${className}`}>
      <button
        onClick={toggleOpen}
        className={`w-full flex items-center justify-between p-4 text-left text-xl font-semibold text-cyan-300 hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 ${isOpen ? 'rounded-t-lg' : 'rounded-lg'}`}
        aria-expanded={isOpen}
        aria-controls="game-info-content"
      >
        <span>Game Info & Rules</span>
        <svg
          className={`w-6 h-6 transform transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
        </svg>
      </button>
      <div
        id="game-info-content"
        className={`transition-all duration-300 ease-in-out overflow-hidden ${isOpen ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'}`} // Increased max-h for more content
      >
        <div className="p-4 border-t border-slate-600 space-y-3 rounded-b-lg">
          {/* Current Game State Section */}
          <div className="pb-3 border-b border-slate-600">
            <h3 className="text-lg font-semibold text-cyan-400 mb-2">Current Game State</h3>
            <div>
              <span className="font-medium text-slate-300">Status:</span>
              <span className={`ml-2 font-bold ${
                gameStatus === GameStatus.PLAYING ? (isGamePausedForEffect ? 'text-yellow-400' : 'text-green-400') :
                isPostGameCooldownActive ? 'text-orange-400' : 
                (gameStatus === GameStatus.WON ? 'text-yellow-300' : 
                (gameStatus === GameStatus.GAME_OVER || gameStatus === GameStatus.INSUFFICIENT_FUNDS || gameStatus === GameStatus.TIME_UP ? 'text-red-400' : 'text-yellow-400'))
              }`}>
                {isPostGameCooldownActive ? `COOLDOWN (${autoRestartCountdown}s)` : (gameStatus === GameStatus.PLAYING && isGamePausedForEffect ? 'PAUSED' : displayedStatusText)}
              </span>
            </div>
            <div>
              <span className="font-medium text-slate-300">Time Left:</span>
              <span className={`ml-2 font-bold ${timeLeft < 10 && timeLeft > 0 && gameStatus === GameStatus.PLAYING && !isGamePausedForEffect ? 'text-red-500 animate-pulse' : 'text-white'}`}>{Math.ceil(timeLeft).toFixed(0)}s</span>
            </div>
            <div>
              <span className="font-medium text-slate-300">Gamers Wallet (Current Round Score):</span>
              <span className="ml-2 text-white font-bold">{score.toFixed(2)} {settings.gameMode === GameMode.MOCK ? "MOCK" : settings.currency}</span>
            </div>
              <div>
              <span className="font-medium text-slate-300">Current Stake:</span>
              <span className="ml-2 text-white">{settings.stakeAmount.toFixed(2)} {settings.gameMode === GameMode.MOCK ? "MOCK" : settings.currency}</span>
            </div>
            <div>
              <span className="font-medium text-slate-300">Mode:</span>
              <span className="ml-2 text-white">{settings.gameMode}</span>
            </div>
          </div>

          {/* Game Rules Section */}
          <div className="text-sm text-slate-300 space-y-3">
            <h3 className="text-lg font-semibold text-cyan-400 mb-2">Game Rules</h3>
            
            <p className="text-xs text-slate-400">Use Arrow Keys or WASD to control the snake. Collect all {MONEY_BALL_PERCENTAGES.length} money balls in {WIN_TIME_LIMIT_SECONDS} seconds to win! Mirror Obstacles penalize score and snake length.</p>

            <ul className="list-disc list-inside space-y-2 pl-2 text-slate-300">
              <li>
                <strong>Objective:</strong> Eat all {MONEY_BALL_PERCENTAGES.length} Money Balls within {WIN_TIME_LIMIT_SECONDS} seconds. Your Gamers Wallet (score) increases with each Money Ball, valued as a percentage of your stake.
              </li>
              <li>
                <strong>Controls:</strong> Use Arrow Keys or W,A,S,D. You cannot immediately reverse direction (e.g., Right to Left) unless the snake is very short ({INITIAL_SNAKE_LENGTH > 2 ? '2' : INITIAL_SNAKE_LENGTH} segments or less).
              </li>
              <li>
                <strong>Snake:</strong> Starts with {INITIAL_SNAKE_LENGTH} segments. Does not grow by eating Money Balls.
              </li>
              <li>
                <strong>Money Balls:</strong> 
                <ul className="list-['-_'] list-inside space-y-1 pl-4">
                    <li>{MONEY_BALL_PERCENTAGES.length} on stage, each with a percentage value of your stake.</li>
                    <li>Move randomly.</li>
                </ul>
              </li>
              <li>
                <strong>Mirror Obstacles:</strong> 
                 <ul className="list-['-_'] list-inside space-y-1 pl-4">
                    <li>{MIRROR_OBSTACLE_COUNT} obstacles fall from the top and land randomly.</li>
                    <li>Collision reduces Gamers Wallet by {(OBSTACLE_PENALTY_PERCENTAGE * 100).toFixed(0)}% of current value.</li>
                    <li>Snake length is reduced by {(OBSTACLE_PENALTY_PERCENTAGE * 100).toFixed(0)}% of current length (min. 1 segment).</li>
                </ul>
              </li>
              <li>
                <strong>Winning:</strong> Eat all Money Balls before time runs out.
                <ul className="list-['-_'] list-inside space-y-1 pl-4">
                    <li>Stake is returned. Total Gamers Wallet amount is paid to your active wallet.</li>
                    <li>Profit = Gamers Wallet - Stake Amount.</li>
                </ul>
              </li>
              <li>
                <strong>Losing:</strong>
                <ul className="list-['-_'] list-inside space-y-1 pl-4">
                    <li>Collision with walls or self.</li>
                    <li>Snake length drops to {SNAKE_MIN_LENGTH_THRESHOLD} segment(s) or less.</li>
                    <li>Time runs out before eating all Money Balls.</li>
                    <li>Stake is committed at game start. If you lose, the amount collected in Gamers Wallet is returned. The difference (Stake - Gamers Wallet) is forfeited to Admin (in Real Mode).</li>
                </ul>
              </li>
               <li>
                <strong>Stake & Game Modes:</strong>
                <ul className="list-['-_'] list-inside space-y-1 pl-4">
                    <li>Stake is deducted from active wallet (Deposit for Real, Mock for Mock) at game start.</li>
                    <li>Insufficient funds will prevent game start.</li>
                </ul>
              </li>
              <li>
                <strong>Wallets:</strong>
                <ul className="list-['-_'] list-inside space-y-1 pl-4">
                    <li><strong>Deposit Wallet:</strong> For Real Game mode.</li>
                    <li><strong>Mock Wallet:</strong> For practice in Mock Game mode.</li>
                    <li><strong>Admin Wallet (Real Mode):</strong> Receives player's stake. Pays out winnings or retains unrecovered stake on loss.</li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollapsibleGameInfo;
