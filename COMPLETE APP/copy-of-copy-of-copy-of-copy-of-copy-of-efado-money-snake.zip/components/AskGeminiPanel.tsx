
import React from 'react';
import Button from './Button';

interface AskGeminiPanelProps {
  userInput: string;
  onUserInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  onSubmit: () => void;
  response: string;
  isLoading: boolean;
  error: string;
  className?: string;
  submitButtonAnimated?: boolean; // New prop
}

const AskGeminiPanel: React.FC<AskGeminiPanelProps> = ({
  userInput,
  onUserInputChange,
  onSubmit,
  response,
  isLoading,
  error,
  className = '',
  submitButtonAnimated = false
}) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSubmit();
    }
  };

  return (
    <div className={`p-4 bg-slate-700 rounded-lg shadow-md ${className}`}>
      <h2 className="text-xl font-semibold text-cyan-300 border-b border-cyan-700 pb-2 mb-3">Ask Gemini</h2>
      <div className="space-y-3">
        <div>
          <label htmlFor="gemini-prompt" className="block text-sm font-medium text-slate-300 mb-1">
            Your Question:
          </label>
          <textarea
            id="gemini-prompt"
            value={userInput}
            onChange={onUserInputChange}
            onKeyDown={handleKeyDown}
            placeholder="e.g., Why is the sky blue?"
            rows={3}
            className="w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500 disabled:opacity-70"
            disabled={isLoading}
            aria-label="Question for Gemini"
          />
        </div>
        <Button onClick={onSubmit} disabled={isLoading || !userInput.trim()} variant="primary" animated={submitButtonAnimated}>
          {isLoading ? 'Thinking...' : 'Send to Gemini'}
        </Button>

        {error && (
          <div className="mt-3 p-3 bg-red-800/50 border border-red-700 rounded-md text-red-300 text-sm">
            <p className="font-semibold">Error:</p>
            <p>{error}</p>
          </div>
        )}

        {response && !error && (
          <div className="mt-3 p-3 bg-slate-600/50 border border-slate-500 rounded-md">
            <h3 className="text-md font-semibold text-cyan-300 mb-1">Gemini's Response:</h3>
            <p className="text-sm text-slate-200 whitespace-pre-wrap">{response}</p>
          </div>
        )}
         {isLoading && !error && (
            <div className="mt-3 text-center text-slate-400">
                <p>Waiting for Gemini's wisdom...</p>
                 <div className="inline-block animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-cyan-500 mt-2"></div>
            </div>
        )}
      </div>
    </div>
  );
};

export default AskGeminiPanel;