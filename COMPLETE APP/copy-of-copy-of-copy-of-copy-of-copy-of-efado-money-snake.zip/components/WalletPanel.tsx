
import React from 'react';
import { WalletBalances } from '../types';
import Button from './Button';

interface WalletPanelProps {
  balances: WalletBalances;
  currency: string;
  onDepositClick: () => void;
  onCashOutClick?: () => void; // New prop for cash out
  className?: string;
  depositButtonAnimated?: boolean;
  disableDeposit?: boolean;
}

const WalletDisplay: React.FC<{ title: string; amount: number; currency?: string; isMock?: boolean }> = ({ title, amount, currency, isMock }) => (
  <div className="p-3 bg-slate-600 rounded-md shadow">
    <h3 className="text-sm font-medium text-cyan-300">{title}</h3>
    <p className="text-lg font-bold text-white">
      {amount.toFixed(2)} 
      <span className="text-xs ml-1">{isMock ? 'MOCK' : currency}</span>
    </p>
  </div>
);

const WalletPanel: React.FC<WalletPanelProps> = ({ 
  balances, 
  currency, 
  onDepositClick, 
  onCashOutClick, 
  className = '', 
  depositButtonAnimated = false, 
  disableDeposit = false 
}) => {
  return (
    <div className={`p-4 bg-slate-700 rounded-lg shadow-md ${className}`}>
      <h2 className="text-xl font-semibold text-cyan-400 neon-text mb-3 text-center md:text-left">Wallets</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 items-start">
        <WalletDisplay title="Deposit Wallet" amount={balances.deposit} currency={currency} />
        <WalletDisplay title="Mock Wallet" amount={balances.mock} isMock />
        <WalletDisplay title="Admin Wallet" amount={balances.admin} currency={currency} />
      </div>
      <div className="mt-4 flex flex-col sm:flex-row justify-center sm:justify-end space-y-2 sm:space-y-0 sm:space-x-2">
        {onCashOutClick && !disableDeposit && ( // disableDeposit can also mean disable cashout for admin view
          <Button 
            onClick={onCashOutClick} 
            variant="secondary" 
            animated={depositButtonAnimated} // Can use same animation prop or a new one
            disabled={balances.deposit <= 0}
          >
            Cash Out from Deposit
          </Button>
        )}
        {!disableDeposit && (
          <Button onClick={onDepositClick} variant="primary" animated={depositButtonAnimated}>
            Deposit to Real Wallet
          </Button>
        )}
      </div>
    </div>
  );
};

export default WalletPanel;
