
import React from 'react';
import { Position, Ball, BallType } from '../types';
import { STAGE_WIDTH, STAGE_HEIGHT, GRID_SIZE, SNAKE_COLOR, WALL_COLOR, STAGE_BG_COLOR, MIRROR_OBSTACLE_COLOR } from '../constants';

interface GameStageProps {
  snake: Position[];
  balls: Ball[];
}

const GameStage: React.FC<GameStageProps> = ({ snake, balls }) => {
  const stageStyle: React.CSSProperties = {
    width: STAGE_WIDTH * GRID_SIZE,
    height: STAGE_HEIGHT * GRID_SIZE,
    boxShadow: `0 0 10px 2px rgba(0, 255, 255, 0.3), 0 0 20px 5px rgba(0, 255, 255, 0.2), inset 0 0 15px rgba(0,0,0,0.5)`,
  };

  return (
    <div 
      className={`relative ${STAGE_BG_COLOR} border-4 ${WALL_COLOR} rounded-md overflow-hidden`}
      style={stageStyle}
      role="grid"
      aria-label="EFADO Money Snake Game Stage"
    >
      {/* Render Snake */}
      {snake.map((segment, index) => (
        <div
          key={`snake-${index}`}
          className={`absolute ${SNAKE_COLOR} rounded-sm shadow-md shadow-green-700/50`}
          style={{
            width: GRID_SIZE - 2, // Snake segments remain slightly smaller than grid cell
            height: GRID_SIZE - 2,
            left: segment.x * GRID_SIZE + 1,
            top: segment.y * GRID_SIZE + 1,
            boxShadow: index === 0 ? '0 0 8px 2px rgba(16, 185, 129, 0.7)' : undefined, 
            zIndex: 10,
          }}
          role="gridcell"
          aria-label={index === 0 ? "Snake head" : "Snake segment"}
        />
      ))}

      {/* Render Balls */}
      {balls.filter(ball => !ball.isEaten).map(ball => {
        const isMirrorObstacle = ball.type === BallType.MIRROR_OBSTACLE;
        const ballColorClass = isMirrorObstacle ? MIRROR_OBSTACLE_COLOR : ball.color;
        
        let ballSizeStyle: React.CSSProperties;
        let ballPositionStyle: React.CSSProperties;
        let specificBallStyle: React.CSSProperties;

        if (isMirrorObstacle) {
          ballSizeStyle = {
            width: GRID_SIZE - 4, // Obstacles are noticeably smaller
            height: GRID_SIZE - 4,
          };
          ballPositionStyle = {
            left: ball.position.x * GRID_SIZE + 2, // Centered smaller obstacle
            top: ball.position.y * GRID_SIZE + 2,
          };
          specificBallStyle = { 
            border: `1px solid #A0AEC0`, 
            boxShadow: `inset 0 0 3px rgba(255,255,255,0.7), 0 0 5px rgba(192,192,192,0.5)`, 
            opacity: 0.85,
          };
        } else { // Money Ball
          ballSizeStyle = {
            width: GRID_SIZE -1, // Money balls are larger, almost filling the cell
            height: GRID_SIZE -1,
          };
          ballPositionStyle = {
            left: ball.position.x * GRID_SIZE + 0.5, // Centered larger ball
            top: ball.position.y * GRID_SIZE + 0.5,
          };
          specificBallStyle = {
            boxShadow: `0 0 7px 2px ${ball.color.replace('bg-','').replace('-500','')}DD, 0 0 12px 3px ${ball.color.replace('bg-','').replace('-500','')}AA, inset 0 0 3px rgba(255,255,255,0.3)`,
            // Make money balls look more solid and vibrant
            opacity: 1,
          };
        }

        return (
          <div
            key={`ball-${ball.id}`}
            className={`absolute rounded-full flex items-center justify-center ${ballColorClass} shadow-xl transition-all duration-100`}
            style={{
              ...ballSizeStyle,
              ...ballPositionStyle,
              zIndex: 5,
              ...specificBallStyle,
            }}
            role="gridcell"
            aria-label={isMirrorObstacle ? "Mirror obstacle" : `Money ball value ${ball.value.toFixed(2)}`}
          >
            {!isMirrorObstacle && <span className="ball-value-text">{ball.value.toFixed(2)}</span>}
          </div>
        );
      })}
    </div>
  );
};

export default GameStage;
