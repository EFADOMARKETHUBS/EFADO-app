
import React, { useState } from 'react';
import Button from '../Button';
import LocationPicker from './LocationPicker';
import { User, UserRole } from '../../types';
import { ADMIN_USERNAME } from '../../constants';


interface SignUpFormProps {
  onSignUpSuccess: (user: User) => void;
  onSwitchToLogin: () => void;
  storedUsers: User[];
  setStoredUsers: React.Dispatch<React.SetStateAction<User[]>>;
}

const SignUpForm: React.FC<SignUpFormProps> = ({ onSignUpSuccess, onSwitchToLogin, storedUsers, setStoredUsers }) => {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [country, setCountry] = useState('');
  const [stateOrRegion, setStateOrRegion] = useState('');
  const [locality, setLocality] = useState('');
  const [error, setError] = useState('');

  const fieldClassName = "w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500";
  const labelClassName = "block text-sm font-medium text-cyan-300 mb-1";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (storedUsers.some(u => u.username === username)) {
      setError('Username already taken.');
      return;
    }
    if (storedUsers.some(u => u.email === email)) {
      setError('Email already registered.');
      return;
    }
    // Basic phone number validation (example)
    if (!/^\+?[0-9\s-]{7,15}$/.test(phoneNumber)) {
        setError('Please enter a valid phone number (e.g., +1234567890).');
        return;
    }


    const newUser: User = {
      id: Date.now().toString(),
      name,
      username,
      phoneNumber,
      email,
      passwordHash: password, // Insecure: storing plain password for simulation
      dateOfBirth,
      country,
      stateOrRegion,
      locality,
      role: username === ADMIN_USERNAME ? 'admin' : 'user', // Assign admin role if username matches
      createdAt: new Date().toISOString(),
    };

    setStoredUsers(prev => [...prev, newUser]);
    onSignUpSuccess(newUser);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <h2 className="text-2xl font-bold text-center text-cyan-400 neon-text">Sign Up</h2>
      {error && <p className="text-red-400 text-sm text-center bg-red-900/50 p-2 rounded">{error}</p>}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label htmlFor="name" className={labelClassName}>Full Name</label>
          <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required className={fieldClassName} />
        </div>
        <div>
          <label htmlFor="username" className={labelClassName}>Username</label>
          <input type="text" id="username" value={username} onChange={(e) => setUsername(e.target.value)} required className={fieldClassName} />
        </div>
        <div>
          <label htmlFor="phoneNumber" className={labelClassName}>Phone Number</label>
          <input type="tel" id="phoneNumber" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} required className={fieldClassName} placeholder="+1234567890"/>
        </div>
        <div>
          <label htmlFor="email" className={labelClassName}>Email</label>
          <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required className={fieldClassName} />
        </div>
        <div>
          <label htmlFor="password" className={labelClassName}>Password</label>
          <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} required className={fieldClassName} minLength={6}/>
        </div>
        <div>
          <label htmlFor="confirmPassword" className={labelClassName}>Confirm Password</label>
          <input type="password" id="confirmPassword" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required className={fieldClassName} />
        </div>
        <div>
          <label htmlFor="dateOfBirth" className={labelClassName}>Date of Birth</label>
          <input type="date" id="dateOfBirth" value={dateOfBirth} onChange={(e) => setDateOfBirth(e.target.value)} required className={fieldClassName} />
        </div>
      </div>

      <LocationPicker
        country={country}
        onCountryChange={setCountry}
        stateOrRegion={stateOrRegion}
        onStateOrRegionChange={setStateOrRegion}
        locality={locality}
        onLocalityChange={setLocality}
        fieldClassName={fieldClassName}
        labelClassName={labelClassName}
      />
      
      <Button type="submit" variant="primary" className="w-full mt-4" animated>
        Sign Up
      </Button>
      <p className="text-sm text-center text-slate-400">
        Already have an account?{' '}
        <button type="button" onClick={onSwitchToLogin} className="text-cyan-400 hover:underline focus:outline-none">
          Login
        </button>
      </p>
    </form>
  );
};

export default SignUpForm;
