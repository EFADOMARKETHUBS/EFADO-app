
import React, { useState } from 'react';
import Button from '../Button';
import { User } from '../../types';

interface LoginFormProps {
  onLoginSuccess: (user: User) => void;
  onSwitchToSignUp: () => void;
  storedUsers: User[]; // Pass stored users for validation
}

const LoginForm: React.FC<LoginFormProps> = ({ onLoginSuccess, onSwitchToSignUp, storedUsers }) => {
  const [identifier, setIdentifier] = useState(''); // Username, email, or phone
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const user = storedUsers.find(
      u => (u.username === identifier || u.email === identifier || u.phoneNumber === identifier) && u.passwordHash === password // Insecure: direct password comparison
    );

    if (user) {
      onLoginSuccess(user);
    } else {
      setError('Invalid credentials or user not found.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <h2 className="text-2xl font-bold text-center text-cyan-400 neon-text">Login</h2>
      {error && <p className="text-red-400 text-sm text-center bg-red-900/50 p-2 rounded">{error}</p>}
      <div>
        <label htmlFor="identifier" className="block text-sm font-medium text-cyan-300 mb-1">
          Username, Email, or Phone
        </label>
        <input
          type="text"
          id="identifier"
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          required
          className="w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500"
        />
      </div>
      <div>
        <label htmlFor="password" className="block text-sm font-medium text-cyan-300 mb-1">
          Password
        </label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500"
        />
      </div>
      <Button type="submit" variant="primary" className="w-full" animated>
        Login
      </Button>
      <p className="text-sm text-center text-slate-400">
        Don't have an account?{' '}
        <button type="button" onClick={onSwitchToSignUp} className="text-cyan-400 hover:underline focus:outline-none">
          Sign Up
        </button>
      </p>
    </form>
  );
};

export default LoginForm;
