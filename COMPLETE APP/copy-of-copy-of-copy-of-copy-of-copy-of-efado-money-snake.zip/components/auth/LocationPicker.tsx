
import React, { useState, useEffect } from 'react';
import { COUNTRIES, STATES_BY_COUNTRY } from '../../data/locationData';

interface LocationPickerProps {
  country: string;
  onCountryChange: (country: string) => void;
  stateOrRegion: string;
  onStateOrRegionChange: (stateOrRegion: string) => void;
  locality: string;
  onLocalityChange: (locality: string) => void;
  fieldClassName?: string;
  labelClassName?: string;
}

const LocationPicker: React.FC<LocationPickerProps> = ({
  country,
  onCountryChange,
  stateOrRegion,
  onStateOrRegionChange,
  locality,
  onLocalityChange,
  fieldClassName = "w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500",
  labelClassName = "block text-sm font-medium text-cyan-300 mb-1",
}) => {
  const [availableStates, setAvailableStates] = useState<string[]>([]);

  useEffect(() => {
    if (country && STATES_BY_COUNTRY[country]) {
      setAvailableStates(STATES_BY_COUNTRY[country]);
    } else {
      setAvailableStates([]);
    }
    // Reset state/region if country changes and current state is not in new country's list
    if (country && STATES_BY_COUNTRY[country] && !STATES_BY_COUNTRY[country].includes(stateOrRegion)) {
        onStateOrRegionChange("");
    } else if (country && !STATES_BY_COUNTRY[country] && stateOrRegion) {
        // If switched to a country with no predefined states, keep typed state if user wants generic input
    }


  }, [country, stateOrRegion, onStateOrRegionChange]);

  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onCountryChange(e.target.value);
    onStateOrRegionChange(""); // Reset state when country changes
  };

  return (
    <>
      <div>
        <label htmlFor="country" className={labelClassName}>Country</label>
        <select
          id="country"
          name="country"
          value={country}
          onChange={handleCountryChange}
          className={fieldClassName}
          required
        >
          <option value="">Select Country</option>
          {COUNTRIES.sort().map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <div>
        <label htmlFor="stateOrRegion" className={labelClassName}>State/Region</label>
        {availableStates.length > 0 ? (
          <select
            id="stateOrRegion"
            name="stateOrRegion"
            value={stateOrRegion}
            onChange={(e) => onStateOrRegionChange(e.target.value)}
            className={fieldClassName}
            required
          >
            <option value="">Select State/Region</option>
            {availableStates.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        ) : (
          <input
            type="text"
            id="stateOrRegion"
            name="stateOrRegion"
            value={stateOrRegion}
            onChange={(e) => onStateOrRegionChange(e.target.value)}
            placeholder="Enter State or Region"
            className={fieldClassName}
            required
          />
        )}
      </div>

      <div>
        <label htmlFor="locality" className={labelClassName}>Locality/City</label>
        <input
          type="text"
          id="locality"
          name="locality"
          value={locality}
          onChange={(e) => onLocalityChange(e.target.value)}
          placeholder="e.g., Ikeja, Manhattan"
          className={fieldClassName}
          required
        />
      </div>
    </>
  );
};

export default LocationPicker;
