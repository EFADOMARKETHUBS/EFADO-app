
import React, { useState } from 'react';
import LoginForm from './LoginForm';
import SignUpForm from './SignUpForm';
import { User, AuthView } from '../../types';

interface AuthPageProps {
  onAuthSuccess: (user: User) => void;
  storedUsers: User[];
  setStoredUsers: React.Dispatch<React.SetStateAction<User[]>>;
}

const AuthPage: React.FC<AuthPageProps> = ({ onAuthSuccess, storedUsers, setStoredUsers }) => {
  const [authView, setAuthView] = useState<AuthView>('login');

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center justify-center p-4 selection:bg-cyan-500 selection:text-cyan-900">
      <header className="mb-8 text-center">
        <h1 className="text-5xl efado-title-animated tracking-wider">EFADO Money Snake</h1>
        <p className="text-slate-400 mt-2 text-lg subtitle-animated-text">Secure Access Portal</p>
      </header>

      <div className="bg-slate-800 p-6 sm:p-8 rounded-lg shadow-2xl w-full max-w-md">
        {authView === 'login' ? (
          <LoginForm
            onLoginSuccess={onAuthSuccess}
            onSwitchToSignUp={() => setAuthView('signup')}
            storedUsers={storedUsers}
          />
        ) : (
          <SignUpForm
            onSignUpSuccess={onAuthSuccess}
            onSwitchToLogin={() => setAuthView('login')}
            storedUsers={storedUsers}
            setStoredUsers={setStoredUsers}
          />
        )}
      </div>
       <footer className="mt-10 text-center text-sm text-slate-500">
        <p>&copy; {new Date().getFullYear()} EFADO Money Snake. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default AuthPage;
