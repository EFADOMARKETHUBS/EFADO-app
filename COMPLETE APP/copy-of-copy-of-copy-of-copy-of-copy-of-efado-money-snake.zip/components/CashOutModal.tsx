
import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import Button from './Button';

interface CashOutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmCashOut: (amount: number, details: { method: string, identifier: string }) => boolean; // Returns true on success
  currency: string;
  maxAmount: number;
  confirmButtonAnimated?: boolean;
}

type CashOutMethod = "bank_transfer" | "crypto_wallet";

const CashOutModal: React.FC<CashOutModalProps> = ({ 
  isOpen, 
  onClose, 
  onConfirmCashOut, 
  currency, 
  maxAmount,
  confirmButtonAnimated = false 
}) => {
  const [amount, setAmount] = useState<string>("");
  const [selectedMethod, setSelectedMethod] = useState<CashOutMethod>("bank_transfer");
  const [identifier, setIdentifier] = useState<string>(""); // Bank account or wallet address
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  useEffect(() => {
    // Reset form when modal opens or method changes
    if (isOpen) {
      setAmount("");
      setIdentifier("");
      setFeedbackMessage(null);
    }
  }, [isOpen, selectedMethod]);

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFeedbackMessage(null);
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      setAmount(value);
    }
  };

  const handleSubmitCashOut = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseFloat(amount);

    if (isNaN(numericAmount) || numericAmount <= 0) {
      setFeedbackMessage("Please enter a valid positive amount.");
      return;
    }
    if (numericAmount > maxAmount) {
      setFeedbackMessage(`Amount exceeds available balance of ${maxAmount.toFixed(2)} ${currency}.`);
      return;
    }
    if (!identifier.trim()) {
      setFeedbackMessage(`Please enter your ${selectedMethod === "bank_transfer" ? "bank account details" : "wallet address"}.`);
      return;
    }

    const success = onConfirmCashOut(numericAmount, { method: selectedMethod, identifier });
    if (success) {
      setFeedbackMessage(`Successfully initiated cash out of ${numericAmount.toFixed(2)} ${currency}.`);
      // Optionally close modal after a delay or keep open with success message
      // onClose(); // Or let parent handle closing based on success
    } else {
      setFeedbackMessage("Cash out failed. Please try again or check your balance.");
    }
  };
  
  const getIdentifierPlaceholder = () => {
    switch(selectedMethod) {
      case "bank_transfer": return "e.g., Bank Name - Account Number";
      case "crypto_wallet": return "e.g., Your Crypto Wallet Address";
      default: return "Details";
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Cash Out from Deposit Wallet (${currency})`} showCloseButton={true}>
      <form onSubmit={handleSubmitCashOut} className="space-y-4">
        <div>
          <label htmlFor="cashOutAmount" className="block text-sm font-medium text-cyan-300 mb-1">
            Amount to Cash Out ({currency})
          </label>
          <input
            type="text"
            id="cashOutAmount"
            value={amount}
            onChange={handleAmountChange}
            placeholder={`Max: ${maxAmount.toFixed(2)}`}
            className="w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500"
            aria-describedby="cashout-amount-feedback"
          />
           <p className="text-xs text-slate-400 mt-1">Available to cash out: {maxAmount.toFixed(2)} {currency}</p>
        </div>

        <div>
            <label className="block text-sm font-medium text-cyan-300 mb-1">Cash Out Method</label>
            <div className="flex space-x-2">
                {(["bank_transfer", "crypto_wallet"] as CashOutMethod[]).map(method => (
                    <Button 
                        type="button"
                        key={method}
                        variant={selectedMethod === method ? 'primary' : 'secondary'}
                        onClick={() => setSelectedMethod(method)}
                        className="flex-1 text-xs sm:text-sm"
                    >
                        {method.replace('_', ' ').toUpperCase()}
                    </Button>
                ))}
            </div>
        </div>

        <div>
          <label htmlFor="cashOutIdentifier" className="block text-sm font-medium text-cyan-300 mb-1">
            {selectedMethod === "bank_transfer" ? "Bank Details (Simulated)" : "Wallet Address (Simulated)"}
          </label>
          <input
            type="text"
            id="cashOutIdentifier"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            placeholder={getIdentifierPlaceholder()}
            className="w-full bg-slate-600 border border-slate-500 text-white rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500"
          />
        </div>
        
        {feedbackMessage && (
          <p id="cashout-amount-feedback" className={`text-sm ${feedbackMessage.startsWith("Successfully") ? 'text-green-400' : 'text-red-400'}`} role="alert">
            {feedbackMessage}
          </p>
        )}

        <div className="flex justify-end pt-2">
          <Button 
            type="submit" 
            variant="primary" 
            disabled={!amount || parseFloat(amount) <= 0 || parseFloat(amount) > maxAmount || !identifier.trim()} 
            animated={confirmButtonAnimated}
          >
            Confirm Cash Out
          </Button>
        </div>
        <p className="text-xs text-slate-400 text-center">This is a simulation. No real money will be transferred.</p>
      </form>
    </Modal>
  );
};

export default CashOutModal;
